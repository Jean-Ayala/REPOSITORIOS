import pyodbc
from app.config import Config

def get_conn():
    return pyodbc.connect(Config.conn_str(), autocommit=False)

def _rows(conn, sql, params=()):
    return conn.execute(sql, params).fetchall()

def _one(conn, sql, params=()):
    return conn.execute(sql, params).fetchone()

def _val(conn, sql, params=()):
    return conn.execute(sql, params).fetchval()

def auth_usuario(username, password):
    sql = """SELECT id, username, rol, nombre_completo
             FROM usuarios WHERE username=? AND password=? AND activo=1"""
    with get_conn() as c:
        r = _one(c, sql, (username, password))
    return {'id':r[0],'username':r[1],'rol':r[2],'nombre':r[3]} if r else None

def get_todos_gestores():
    sql = "SELECT id, nombre_completo FROM usuarios WHERE rol='gestor' AND activo=1 ORDER BY nombre_completo"
    with get_conn() as c:
        rows = _rows(c, sql)
    return [{'id':r[0],'nombre':r[1]} for r in rows]

def padron_tiene_carga(mes):
    with get_conn() as c:
        return (_val(c,"SELECT COUNT(1) FROM padron_mensual WHERE mes_carga=?",(mes,)) or 0) > 0

def borrar_padron_mes(mes, conn):
    conn.execute("DELETE FROM padron_mensual WHERE mes_carga=?", (mes,))

def insertar_padron_batch(filas, mes, supervisor_id, lote_id, conn):
    sql = """INSERT INTO padron_mensual
             (cu,cj,nombre_cliente,producto,saldo_total,dias_mora,mes_carga,subido_por,lote_id)
             VALUES (?,?,?,?,?,?,?,?,?)"""
    BATCH = 2000
    for i in range(0, len(filas), BATCH):
        conn.executemany(sql, [
            (r[0],r[1],r[2],r[3],r[4],r[5],mes,supervisor_id,lote_id)
            for r in filas[i:i+BATCH]
        ])

def buscar_en_padron(cu, cj, mes):
    sql = """SELECT TOP 1 cu,cj,nombre_cliente,producto,saldo_total,dias_mora,
                    ISNULL(monto_maximo,saldo_total),ISNULL(monto_minimo,0)
             FROM padron_mensual
             WHERE mes_carga=? AND (cu=? OR (? IS NOT NULL AND cj=?))
             ORDER BY CASE WHEN cu=? THEN 0 ELSE 1 END"""
    with get_conn() as c:
        r = _one(c, sql, (mes, cu, cj or None, cj or None, cu))
    if r:
        return {'cu':r[0],'cj':r[1],'nombre_cliente':r[2],
                'producto':r[3],'saldo_total':float(r[4] or 0),
                'dias_mora':r[5],'monto_maximo':float(r[6] or 0),
                'monto_minimo':float(r[7] or 0)}
    return None

def stats_padron(mes):
    sql = """SELECT COUNT(*), SUM(saldo_total), MIN(cargado_en), u.nombre_completo
             FROM padron_mensual pm JOIN usuarios u ON u.id=pm.subido_por
             WHERE pm.mes_carga=? GROUP BY u.nombre_completo"""
    with get_conn() as c:
        r = _one(c, sql, (mes,))
    if r:
        return {'total':r[0],'saldo_total':float(r[1] or 0),
                'fecha':str(r[2])[:19],'subido_por':r[3]}
    return {}

def get_cargas_padron():
    sql = """SELECT cp.id, cp.nombre_archivo, cp.mes_carga, cp.total_filas,
                    cp.filas_ok, cp.filas_error, cp.estado,
                    CONVERT(VARCHAR(19),cp.fecha_inicio,120), u.nombre_completo
             FROM cargas_padron cp JOIN usuarios u ON u.id=cp.supervisor_id
             ORDER BY cp.id DESC"""
    with get_conn() as c:
        rows = _rows(c, sql)
    cols = ['id','archivo','mes','total','ok','error','estado','fecha','supervisor']
    return [dict(zip(cols,r)) for r in rows]

def reg_carga_padron(sup_id, nombre, ruta, mes):
    sql = """INSERT INTO cargas_padron (supervisor_id,nombre_archivo,ruta_archivo,mes_carga)
             OUTPUT INSERTED.id VALUES (?,?,?,?)"""
    with get_conn() as c:
        cid = _val(c, sql, (sup_id, nombre, ruta, mes))
        c.commit()
    return cid

def upd_carga_padron(cid, total, ok, err, estado, msg=None):
    sql = """UPDATE cargas_padron
             SET total_filas=?,filas_ok=?,filas_error=?,estado=?,
                 fecha_fin=GETDATE(),mensaje_error=?
             WHERE id=?"""
    with get_conn() as c:
        c.execute(sql, (total, ok, err, estado, msg, cid))
        c.commit()

def get_campanas_activas():
    sql = """SELECT id,nombre,descripcion,monto_minimo,
                    CONVERT(VARCHAR(10),fecha_inicio,103),
                    CONVERT(VARCHAR(10),fecha_fin,103)
             FROM campanas WHERE activa=1 ORDER BY fecha_fin DESC"""
    with get_conn() as c:
        rows = _rows(c, sql)
    cols = ['id','nombre','descripcion','monto_minimo','fecha_inicio','fecha_fin']
    return [dict(zip(cols,r)) for r in rows]

def get_todas_campanas():
    sql = """SELECT c.id,c.nombre,c.descripcion,c.monto_minimo,
                    CONVERT(VARCHAR(10),c.fecha_inicio,103),
                    CONVERT(VARCHAR(10),c.fecha_fin,103),
                    c.activa, u.nombre_completo,
                    CONVERT(VARCHAR(19),c.creado_en,120)
             FROM campanas c JOIN usuarios u ON u.id=c.creado_por
             ORDER BY c.id DESC"""
    with get_conn() as c:
        rows = _rows(c, sql)
    cols = ['id','nombre','descripcion','monto_minimo','fecha_inicio',
            'fecha_fin','activa','creado_por','creado_en']
    return [dict(zip(cols,r)) for r in rows]

def crear_campana(data, sup_id):
    sql = """INSERT INTO campanas (nombre,descripcion,monto_minimo,fecha_inicio,fecha_fin,creado_por)
             OUTPUT INSERTED.id VALUES (?,?,?,?,?,?)"""
    with get_conn() as c:
        cid = _val(c, sql, (data['nombre'],data.get('descripcion',''),
                             data['monto_minimo'],data['fecha_inicio'],
                             data['fecha_fin'],sup_id))
        c.commit()
    return cid

def toggle_campana(cid, activa):
    with get_conn() as c:
        c.execute("UPDATE campanas SET activa=? WHERE id=?", (1 if activa else 0, cid))
        c.commit()

def crear_solicitud(d):
    sql = """INSERT INTO solicitudes
               (cu,cj,nombre_cliente,producto,saldo_total,dias_mora,
                campana_id,monto_minimo_camp,pago_realizado,monto_a_condonar,
                gestor_id,estado,observacion_gestor,mes_referencia,fecha_envio)
             OUTPUT INSERTED.id
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,
                     CASE WHEN ?='Enviado' THEN GETDATE() ELSE NULL END)"""
    estado = d.get('estado','Borrador')
    with get_conn() as c:
        sid = _val(c, sql, (
            d['cu'], d.get('cj',''), d['nombre_cliente'],
            d.get('producto',''), d.get('saldo_total',0), d.get('dias_mora'),
            d['campana_id'], d['monto_minimo_camp'],
            d['pago_realizado'], d['monto_a_condonar'],
            d['gestor_id'], estado, d.get('observacion_gestor',''),
            d.get('mes_referencia',''), estado
        ))
        c.execute("""INSERT INTO historial_solicitudes
                     (solicitud_id,estado_anterior,estado_nuevo,comentario,usuario_id)
                     VALUES (?,NULL,?,'Solicitud creada',?)""",
                  (sid, estado, d['gestor_id']))
        c.commit()
    return sid

def editar_solicitud(sid, d, uid):
    sql = """UPDATE solicitudes SET
               cu=?,cj=?,nombre_cliente=?,producto=?,saldo_total=?,dias_mora=?,
               campana_id=?,monto_minimo_camp=?,pago_realizado=?,monto_a_condonar=?,
               observacion_gestor=?
             WHERE id=? AND estado='Borrador'"""
    with get_conn() as c:
        c.execute(sql, (
            d['cu'],d.get('cj',''),d['nombre_cliente'],d.get('producto',''),
            d.get('saldo_total',0),d.get('dias_mora'),
            d['campana_id'],d['monto_minimo_camp'],
            d['pago_realizado'],d['monto_a_condonar'],
            d.get('observacion_gestor',''), sid
        ))
        c.commit()

def cambiar_estado_solicitud(sid, nuevo, uid, comentario=None):
    with get_conn() as c:
        r = _one(c,"SELECT estado FROM solicitudes WHERE id=?",(sid,))
        if not r: return False
        ant = r[0]
        extra_sql, extra_params = "", []
        if nuevo=='Enviado':
            extra_sql=",fecha_envio=GETDATE()"
        elif nuevo in ('Aprobado','Rechazado'):
            extra_sql=",fecha_resolucion=GETDATE(),resuelto_por=?,comentario_resolucion=?"
            extra_params=[uid, comentario]
        c.execute(f"UPDATE solicitudes SET estado=?{extra_sql} WHERE id=?",
                  [nuevo]+extra_params+[sid])
        c.execute("""INSERT INTO historial_solicitudes
                     (solicitud_id,estado_anterior,estado_nuevo,comentario,usuario_id)
                     VALUES (?,?,?,?,?)""", (sid,ant,nuevo,comentario,uid))
        c.commit()
    return True

def get_solicitud(sid):
    sql = """SELECT s.id,s.cu,s.cj,s.nombre_cliente,s.producto,
                    s.saldo_total,s.dias_mora,
                    s.campana_id, ca.nombre AS campana_nombre,
                    s.monto_minimo_camp,s.pago_realizado,s.monto_a_condonar,
                    s.pago_conforme,s.diferencia_pago,
                    s.gestor_id, ug.nombre_completo, ug.username,
                    s.estado,s.observacion_gestor,
                    CONVERT(VARCHAR(19),s.fecha_creacion,120),
                    CONVERT(VARCHAR(19),s.fecha_envio,120),
                    CONVERT(VARCHAR(19),s.fecha_resolucion,120),
                    s.comentario_resolucion,
                    ur.nombre_completo,
                    s.mes_referencia
             FROM solicitudes s
             JOIN campanas ca ON ca.id=s.campana_id
             JOIN usuarios ug ON ug.id=s.gestor_id
             LEFT JOIN usuarios ur ON ur.id=s.resuelto_por
             WHERE s.id=?"""
    cols=['id','cu','cj','nombre_cliente','producto','saldo_total','dias_mora',
          'campana_id','campana_nombre','monto_minimo_camp','pago_realizado',
          'monto_a_condonar','pago_conforme','diferencia_pago',
          'gestor_id','gestor_nombre','gestor_user',
          'estado','observacion_gestor','fecha_creacion','fecha_envio',
          'fecha_resolucion','comentario_resolucion','resuelto_por_nombre','mes_referencia']
    with get_conn() as c:
        r = _one(c, sql, (sid,))
    return dict(zip(cols,r)) if r else None

def get_historial_solicitud(sid):
    sql = """SELECT h.estado_anterior,h.estado_nuevo,h.comentario,
                    CONVERT(VARCHAR(19),h.fecha_hora,120), u.nombre_completo, u.rol
             FROM historial_solicitudes h JOIN usuarios u ON u.id=h.usuario_id
             WHERE h.solicitud_id=? ORDER BY h.id"""
    with get_conn() as c:
        rows = _rows(c, sql, (sid,))
    cols=['estado_ant','estado_nuevo','comentario','fecha_hora','usuario','rol']
    return [dict(zip(cols,r)) for r in rows]

def _build_where(filtros, alias='s'):
    w, p = ['1=1'], []
    if filtros.get('gestor_id'):
        w.append(f'{alias}.gestor_id=?'); p.append(filtros['gestor_id'])
    if filtros.get('estado'):
        w.append(f'{alias}.estado=?'); p.append(filtros['estado'])
    if filtros.get('campana_id'):
        w.append(f'{alias}.campana_id=?'); p.append(filtros['campana_id'])
    if filtros.get('solo_alertas'):
        w.append(f'{alias}.pago_conforme=0')
    if filtros.get('q'):
        w.append(f'({alias}.cu LIKE ? OR {alias}.nombre_cliente LIKE ? OR {alias}.cj LIKE ?)')
        b=f"%{filtros['q']}%"; p+=[b,b,b]
    if filtros.get('mes'):
        w.append(f'{alias}.mes_referencia=?'); p.append(filtros['mes'])
    return ' AND '.join(w), p

def get_solicitudes_gestor(gestor_id, page=1, per_page=50, estado=None):
    filt={'gestor_id':gestor_id}
    if estado: filt['estado']=estado
    where, params = _build_where(filt)
    offset=(page-1)*per_page
    sql=f"""SELECT s.id,s.cu,s.cj,s.nombre_cliente,s.producto,
                   s.saldo_total,s.pago_realizado,s.monto_a_condonar,
                   s.monto_minimo_camp,s.pago_conforme,s.estado,
                   ca.nombre,CONVERT(VARCHAR(19),s.fecha_creacion,120)
            FROM solicitudes s JOIN campanas ca ON ca.id=s.campana_id
            WHERE {where}
            ORDER BY s.id DESC
            OFFSET ? ROWS FETCH NEXT ? ROWS ONLY"""
    cols=['id','cu','cj','nombre_cliente','producto','saldo_total',
          'pago_realizado','monto_a_condonar','monto_minimo_camp',
          'pago_conforme','estado','campana','fecha_creacion']
    with get_conn() as c:
        rows=_rows(c,sql,params+[offset,per_page])
        total=_val(c,f"SELECT COUNT(1) FROM solicitudes s WHERE {where}",params)
    return [dict(zip(cols,r)) for r in rows], total or 0

def get_solicitudes_supervisor(filtros, page=1, per_page=50):
    where, params = _build_where(filtros)
    offset=(page-1)*per_page
    sql=f"""SELECT s.id,s.cu,s.cj,s.nombre_cliente,s.producto,
                   s.saldo_total,s.pago_realizado,s.monto_a_condonar,
                   s.monto_minimo_camp,s.pago_conforme,s.diferencia_pago,
                   s.estado,ca.nombre,
                   ug.nombre_completo,ug.username,
                   CONVERT(VARCHAR(16),s.fecha_creacion,120),
                   CONVERT(VARCHAR(16),s.fecha_envio,120)
            FROM solicitudes s
            JOIN campanas ca ON ca.id=s.campana_id
            JOIN usuarios ug ON ug.id=s.gestor_id
            WHERE {where}
            ORDER BY CASE s.estado WHEN 'Enviado' THEN 0 ELSE 1 END,
                     s.pago_conforme ASC, s.id DESC
            OFFSET ? ROWS FETCH NEXT ? ROWS ONLY"""
    count_sql=f"""SELECT COUNT(1) FROM solicitudes s
                  JOIN campanas ca ON ca.id=s.campana_id
                  JOIN usuarios ug ON ug.id=s.gestor_id WHERE {where}"""
    cols=['id','cu','cj','nombre_cliente','producto','saldo_total',
          'pago_realizado','monto_a_condonar','monto_minimo_camp',
          'pago_conforme','diferencia_pago','estado','campana',
          'gestor_nombre','gestor_user','fecha_creacion','fecha_envio']
    with get_conn() as c:
        rows=_rows(c,sql,params+[offset,per_page])
        total=_val(c,count_sql,params)
    return [dict(zip(cols,r)) for r in rows], total or 0

def get_kpis_supervisor(mes=None):
    extra=''; p=[]
    if mes: extra='WHERE mes_referencia=?'; p=[mes]
    sql=f"""SELECT
        COUNT(*),
        SUM(CASE WHEN estado='Enviado'   THEN 1 ELSE 0 END),
        SUM(CASE WHEN estado='Aprobado'  THEN 1 ELSE 0 END),
        SUM(CASE WHEN estado='Rechazado' THEN 1 ELSE 0 END),
        SUM(CASE WHEN estado='Observado' THEN 1 ELSE 0 END),
        SUM(CASE WHEN estado='Borrador'  THEN 1 ELSE 0 END),
        SUM(CASE WHEN pago_conforme=0    THEN 1 ELSE 0 END),
        SUM(CASE WHEN estado='Aprobado'  THEN monto_a_condonar ELSE 0 END),
        SUM(pago_realizado),
        SUM(CASE WHEN pago_conforme=0 AND estado IN ('Rechazado','Observado')
                 THEN monto_a_condonar ELSE 0 END),
        COUNT(DISTINCT gestor_id)
    FROM solicitudes {extra}"""
    with get_conn() as c:
        r=_one(c,sql,p)
    keys=['total','enviadas','aprobadas','rechazadas','observadas','borradores',
          'alertas','monto_condonado','monto_recuperado','perdidas_evitadas','gestores_activos']
    result = {}
    for k, v in zip(keys, r):
        if k in ('monto_condonado','monto_recuperado','perdidas_evitadas'):
            result[k] = float(v) if v is not None else 0.0
        else:
            result[k] = int(v) if v is not None else 0
    return result

def get_monto_por_campana():
    sql="""SELECT ca.nombre,
                  SUM(CASE WHEN s.estado='Aprobado' THEN s.monto_a_condonar ELSE 0 END),
                  COUNT(*)
           FROM solicitudes s JOIN campanas ca ON ca.id=s.campana_id
           GROUP BY ca.nombre ORDER BY 2 DESC"""
    with get_conn() as c:
        rows=_rows(c,sql)
    return [{'campana':r[0],'monto':float(r[1] or 0),'total':r[2]} for r in rows]

def log(uid, accion, detalle=None, tabla=None, id_ref=None, ip=None):
    try:
        sql="""INSERT INTO bitacora (usuario_id,accion,detalle,tabla_ref,id_ref,ip)
               VALUES (?,?,?,?,?,?)"""
        with get_conn() as c:
            c.execute(sql,(uid,accion,detalle,tabla,str(id_ref) if id_ref else None,ip))
            c.commit()
    except Exception:
        pass

def get_bitacora(page=1, per_page=100, uid_filter=None):
    where='1=1'; params=[]
    if uid_filter: where='b.usuario_id=?'; params=[uid_filter]
    offset=(page-1)*per_page
    sql=f"""SELECT b.id,b.accion,b.detalle,b.tabla_ref,b.id_ref,b.ip,
                   CONVERT(VARCHAR(19),b.fecha_hora,120),
                   u.nombre_completo,u.username,u.rol
            FROM bitacora b JOIN usuarios u ON u.id=b.usuario_id
            WHERE {where} ORDER BY b.id DESC
            OFFSET ? ROWS FETCH NEXT ? ROWS ONLY"""
    cols=['id','accion','detalle','tabla','id_ref','ip','fecha_hora','nombre','username','rol']
    with get_conn() as c:
        rows=_rows(c,sql,params+[offset,per_page])
        total=_val(c,f"SELECT COUNT(1) FROM bitacora b WHERE {where}",params)
    return [dict(zip(cols,r)) for r in rows], total or 0

def get_resumen_por_gestor():
    sql = """
        SELECT u.id, u.username, u.nombre_completo,
            COUNT(s.id),
            SUM(CASE WHEN s.estado='Enviado'   THEN 1 ELSE 0 END),
            SUM(CASE WHEN s.estado='Aprobado'  THEN 1 ELSE 0 END),
            SUM(CASE WHEN s.estado='Rechazado' THEN 1 ELSE 0 END),
            SUM(CASE WHEN s.estado='Observado' THEN 1 ELSE 0 END),
            SUM(CASE WHEN s.estado='Borrador'  THEN 1 ELSE 0 END),
            SUM(CASE WHEN s.pago_conforme=0    THEN 1 ELSE 0 END),
            MAX(CONVERT(VARCHAR(19),s.fecha_creacion,120))
        FROM usuarios u
        LEFT JOIN solicitudes s ON s.gestor_id = u.id
        WHERE u.rol = 'gestor' AND u.activo = 1
        GROUP BY u.id, u.username, u.nombre_completo
        ORDER BY COUNT(s.id) DESC
    """
    with get_conn() as c:
        rows = _rows(c, sql)
    cols = ['id','username','nombre','total','enviadas','aprobadas',
            'rechazadas','observadas','borradores','alertas','ultima_actividad']
    return [dict(zip(cols, r)) for r in rows]

def get_bitacora_extendida(page=1, per_page=100, uid_filter=None,
                            accion_filter=None, fecha_desde=None, fecha_hasta=None):
    where = ['1=1']
    params = []
    if uid_filter:
        where.append('b.usuario_id=?'); params.append(uid_filter)
    if accion_filter:
        where.append('b.accion LIKE ?'); params.append(f'%{accion_filter}%')
    if fecha_desde:
        where.append('CAST(b.fecha_hora AS DATE) >= ?'); params.append(fecha_desde)
    if fecha_hasta:
        where.append('CAST(b.fecha_hora AS DATE) <= ?'); params.append(fecha_hasta)
    where_str = ' AND '.join(where)
    offset = (page-1)*per_page
    sql = f"""
        SELECT b.id, b.accion, b.detalle, b.tabla_ref, b.id_ref, b.ip,
               CONVERT(VARCHAR(19),b.fecha_hora,120),
               u.nombre_completo, u.username, u.rol
        FROM bitacora b JOIN usuarios u ON u.id=b.usuario_id
        WHERE {where_str}
        ORDER BY b.id DESC
        OFFSET ? ROWS FETCH NEXT ? ROWS ONLY
    """
    count_sql = f"SELECT COUNT(1) FROM bitacora b WHERE {where_str}"
    cols = ['id','accion','detalle','tabla','id_ref','ip',
            'fecha_hora','nombre','username','rol']
    with get_conn() as c:
        rows  = _rows(c, sql, params+[offset, per_page])
        total = _val(c, count_sql, params)
    return [dict(zip(cols, r)) for r in rows], total or 0

def get_top_gestores(limit=3):
    sql = f"""
        SELECT TOP {limit}
            u.nombre_completo,
            u.username,
            SUM(CASE WHEN s.estado='Aprobado'  THEN 1 ELSE 0 END) AS aprobadas,
            SUM(CASE WHEN s.estado='Enviado'   THEN 1 ELSE 0 END) AS enviadas,
            SUM(CASE WHEN s.estado='Rechazado' THEN 1 ELSE 0 END) AS rechazadas,
            COUNT(s.id) AS total
        FROM cob_tr_usuarios_recovery u
        LEFT JOIN cob_tr_solicitudes_recovery s ON s.gestor_id = u.id
        WHERE u.rol = 'gestor' AND u.activo = 1
        GROUP BY u.nombre_completo, u.username
        ORDER BY aprobadas DESC, total DESC
    """
    with get_conn() as c:
        rows = _rows(c, sql)
    cols = ['nombre','username','aprobadas','enviadas','rechazadas','total']
    return [dict(zip(cols, r)) for r in rows]

# ================================================================
# PADRÓN — nuevas funciones con campos extendidos
# ================================================================

def insertar_padron_batch_v2(filas, mes, supervisor_id, lote_id, conn):
    sql = """INSERT INTO cob_tr_padron_mensual_recovery
             (periodo,cu,cj,nombre_cliente,producto,grupo_producto,situacion,
              capital,deuda_total,tipo_documento,nro_doc,fecha_castigo,
              importe_cancelacion_minimo,importe_cancelacion_optimo,importe_cancelacion_maximo,
              saldo_total,mes_carga,subido_por,lote_id)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,ISNULL(?,0),?,?,?)"""
    BATCH = 2000
    cursor = conn.cursor()
    for i in range(0, len(filas), BATCH):
        lote = filas[i:i+BATCH]
        params = [
            (r[0],r[1],r[2],r[3],r[4],r[5],r[6],
             r[7],r[8],r[9],r[10],r[11],
             r[12],r[13],r[14],
             r[7],  # saldo_total = capital
             mes, supervisor_id, lote_id)
            for r in lote
        ]
        cursor.executemany(sql, params)
    cursor.close()

def buscar_en_padron_por_cj(cj, mes):
    """Busca por CJ y devuelve datos base del cliente."""
    sql = """SELECT TOP 1 cu,cj,nombre_cliente,producto,
                    ISNULL(capital,0),
                    CONVERT(VARCHAR(10),fecha_castigo,103),
                    grupo_producto, situacion
             FROM cob_tr_padron_mensual_recovery
             WHERE cj=? AND mes_carga=?
             ORDER BY id"""
    with get_conn() as c:
        r = _one(c, sql, (cj, mes))
    if r:
        return {'cu':r[0],'cj':r[1],'nombre_cliente':r[2],
                'producto':r[3],'capital':float(r[4] or 0),
                'fecha_castigo':r[5] or '','grupo':r[6] or '',
                'situacion':r[7] or ''}
    return None

def get_periodos_por_cj(cj):
    """Devuelve los periodos disponibles para un CJ en el padrón."""
    sql = """SELECT DISTINCT periodo, mes_carga
             FROM cob_tr_padron_mensual_recovery
             WHERE cj=? AND periodo IS NOT NULL AND periodo != ''
             ORDER BY periodo DESC"""
    with get_conn() as c:
        rows = _rows(c, sql, (cj,))
    return [{'periodo':r[0],'mes':r[1]} for r in rows]

def get_montos_por_cj_periodo(cj, periodo):
    """Devuelve los montos mínimo, óptimo y máximo para un CJ y periodo."""
    sql = """SELECT TOP 1
                    ISNULL(importe_cancelacion_minimo,0),
                    ISNULL(importe_cancelacion_optimo,0),
                    ISNULL(importe_cancelacion_maximo,0),
                    ISNULL(capital,0)
             FROM cob_tr_padron_mensual_recovery
             WHERE cj=? AND periodo=?"""
    with get_conn() as c:
        r = _one(c, sql, (cj, periodo))
    if r:
        return {'minimo':float(r[0]),'optimo':float(r[1]),
                'maximo':float(r[2]),'capital':float(r[3])}
    return None

def get_stats_niveles_pago(mes=None):
    """Para el dashboard: cuántos pagaron en cada nivel."""
    extra = "WHERE mes_referencia=?" if mes else ""
    p = [mes] if mes else []
    sql = f"""SELECT
        SUM(CASE WHEN nivel_pago='MINIMO'  THEN 1 ELSE 0 END),
        SUM(CASE WHEN nivel_pago='OPTIMO'  THEN 1 ELSE 0 END),
        SUM(CASE WHEN nivel_pago='MAXIMO'  THEN 1 ELSE 0 END),
        SUM(CASE WHEN nivel_pago='ALERTA'  THEN 1 ELSE 0 END),
        SUM(CASE WHEN nivel_pago='MAXIMO' OR nivel_pago='OPTIMO'
                 THEN 1 ELSE 0 END)
    FROM cob_tr_solicitudes_recovery {extra}"""
    with get_conn() as c:
        r = _one(c, sql, p)
    return {
        'minimo':   int(r[0] or 0),
        'optimo':   int(r[1] or 0),
        'maximo':   int(r[2] or 0),
        'alerta':   int(r[3] or 0),
        'sobre_optimo': int(r[4] or 0),
    }
