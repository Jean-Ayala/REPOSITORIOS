import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

class Config:
    # ── Flask ──────────────────────────────────────────────────
    SECRET_KEY = os.environ.get('SECRET_KEY', 'recovery_ib_2025_clave_secreta')

    # ── SQL Server ─────────────────────────────────────────────
    # Trabajo  → r's528vp04\bdt'       / 'gic'
    # Casa     → r'localhost\SQLEXPRESS'/ 'gic_recovery'
    DB_SERVER   = os.environ.get('DB_SERVER',   r'localhost\SQLEXPRESS')
    DB_DATABASE = os.environ.get('DB_DATABASE', 'gic_recovery')
    DB_DRIVER   = os.environ.get('DB_DRIVER',   'ODBC Driver 17 for SQL Server')
    DB_TRUSTED  = os.environ.get('DB_TRUSTED',  'yes')   # 'yes' = Windows Auth
    DB_USER     = os.environ.get('DB_USER', '')
    DB_PASS     = os.environ.get('DB_PASS', '')

    # ── Archivos ───────────────────────────────────────────────
    UPLOAD_FOLDER  = os.path.join(BASE_DIR, 'uploads')
    MAX_CONTENT_MB = 200
    ALLOWED_EXCEL  = {'xlsx', 'xls', 'csv'}

    # ── Paginación ─────────────────────────────────────────────
    ROWS_PER_PAGE = 50

    @classmethod
    def conn_str(cls):
        if cls.DB_TRUSTED == 'yes':
            return (
                f"DRIVER={{{cls.DB_DRIVER}}};"
                f"SERVER={cls.DB_SERVER};"
                f"DATABASE={cls.DB_DATABASE};"
                "Trusted_Connection=yes;"
                "TrustServerCertificate=yes;"
            )
        return (
            f"DRIVER={{{cls.DB_DRIVER}}};"
            f"SERVER={cls.DB_SERVER};"
            f"DATABASE={cls.DB_DATABASE};"
            f"UID={cls.DB_USER};PWD={cls.DB_PASS};"
            "TrustServerCertificate=yes;"
        )
