from functools import wraps
from flask import session, redirect, url_for, flash, request

def login_required(f):
    @wraps(f)
    def deco(*a,**kw):
        if 'uid' not in session:
            flash('Inicia sesión para continuar.','warning')
            return redirect(url_for('auth.login'))
        return f(*a,**kw)
    return deco

def role_required(*roles):
    def dec(f):
        @wraps(f)
        def deco(*a,**kw):
            if 'uid' not in session:
                return redirect(url_for('auth.login'))
            if session.get('rol') not in roles:
                flash('Sin permisos para esa sección.','danger')
                return redirect(url_for('auth.login'))
            return f(*a,**kw)
        return deco
    return dec

def me():
    return {'id':session.get('uid'),'username':session.get('username'),
            'rol':session.get('rol'),'nombre':session.get('nombre')}

def ip():
    return (request.headers.get('X-Forwarded-For',request.remote_addr) or '').split(',')[0].strip()
