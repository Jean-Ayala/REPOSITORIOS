// Auto-cerrar flashes
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.flash').forEach(f => {
    setTimeout(() => { f.style.transition='opacity .5s'; f.style.opacity='0';
      setTimeout(()=>f.remove(),500); }, 5000);
  });
});
