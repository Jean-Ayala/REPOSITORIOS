import os, uuid, pandas as pd
from datetime import datetime
from app.config import Config

def allowed(filename):
    return '.' in filename and filename.rsplit('.',1)[1].lower() in Config.ALLOWED_EXCEL

def allowed_pdf(filename):
    return '.' in filename and filename.rsplit('.',1)[1].lower() == 'pdf'

def save_file(file, sub=''):
    base = os.path.join(Config.UPLOAD_FOLDER, sub)
    os.makedirs(base, exist_ok=True)
    ext  = file.filename.rsplit('.',1)[-1].lower()
    name = f"{uuid.uuid4().hex}.{ext}"
    path = os.path.join(base, name)
    file.save(path)
    return name, path

COL_MAP = {
    'periodo':   ['periodo','period'],
    'cu':        ['cu','cuenta_unica','cuenta unica'],
    'cj':        ['cj','codigo_juicio','cod_juicio','juicio'],
    'nombre':    ['cliente','nombre','nombre_cliente','nombres'],
    'producto':  ['producto','tipo_producto'],
    'grupo':     ['grupo_producto','grupo'],
    'situacion': ['situacion'],
    'capital':   ['capital'],
    'deuda':     ['deuda_total','deuda'],
    'tipo_doc':  ['tipo_documento','tipo_doc'],
    'nro_doc':   ['nro_doc','nro_documento'],
    'fecha_castigo': ['fecha_castigo','fecha castigo'],
    'minimo':    ['importe_cancelacion_minimo','cancelacion_minimo','monto_minimo','minimo'],
    'optimo':    ['importe_cancelacion_optimo','cancelacion_optimo','monto_optimo','optimo'],
    'maximo':    ['importe_cancelacion_maximo','cancelacion_maximo','monto_maximo','maximo'],
}

def _norm(s): return str(s).strip().lower().replace(' ','_').replace('-','_')

def detectar_cols(df_cols):
    norm = {_norm(c): c for c in df_cols}
    res  = {}
    for campo, alias in COL_MAP.items():
        for a in alias:
            if _norm(a) in norm:
                res[campo] = norm[_norm(a)]; break
    return res

def leer_excel_padron(ruta):
    try:
        ext = ruta.rsplit('.',1)[-1].lower()
        df  = pd.read_csv(ruta, dtype=str, encoding='utf-8-sig', low_memory=False) \
              if ext=='csv' else pd.read_excel(ruta, dtype=str, engine='openpyxl')
        df.columns = [str(c).strip() for c in df.columns]
        mapa = detectar_cols(df.columns.tolist())
        if 'cj' not in mapa and 'nombre' not in mapa:
            return [], 0, 0, (f"No se encontraron columnas. Detectadas: {', '.join(df.columns[:8])}")
        filas, err = [], 0
        for _, row in df.iterrows():
            def g(k):
                col = mapa.get(k)
                v   = str(row.get(col,'') if col else '').strip()
                return None if v in ('','nan','None') else v
            cj = g('cj'); nom = g('nombre')
            if not cj or not nom: err+=1; continue
            def to_dec(k):
                v = g(k)
                if not v: return None
                try: return float(str(v).replace(',','').replace('S/','').strip())
                except: return None
            def to_date(k):
                v = g(k)
                if not v: return None
                try:
                    for fmt in ['%d/%m/%Y','%Y-%m-%d','%d-%m-%Y','%Y%m%d']:
                        try: return datetime.strptime(v, fmt).strftime('%Y-%m-%d')
                        except: continue
                except: return None
            filas.append((
                (g('periodo') or '')[:10],
                (g('cu') or '')[:30],
                cj[:30],
                nom[:150],
                (g('producto') or '')[:80],
                (g('grupo') or '')[:80],
                (g('situacion') or '')[:50],
                to_dec('capital'),
                to_dec('deuda'),
                (g('tipo_doc') or '')[:50],
                (g('nro_doc') or '')[:50],
                to_date('fecha_castigo'),
                to_dec('minimo'),
                to_dec('optimo'),
                to_dec('maximo'),
            ))
        return filas, len(filas), err, None
    except Exception as e:
        return [], 0, 0, f"Error al leer archivo: {e}"

def fmt_moneda(valor):
    if valor is None: return '—'
    try: return f"S/ {float(valor):,.2f}"
    except: return '—'

def exportar_excel(registros):
    base = os.path.join(Config.UPLOAD_FOLDER, 'exports')
    os.makedirs(base, exist_ok=True)
    nombre = f"recovery_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    ruta   = os.path.join(base, nombre)
    if not registros:
        pd.DataFrame().to_excel(ruta, index=False)
        return ruta, nombre
    df = pd.DataFrame(registros)
    df.to_excel(ruta, index=False, sheet_name='Recovery')
    return ruta, nombre

def mes_actual(): return datetime.now().strftime('%Y-%m')

def fmt_mes(m):
    meses=['Enero','Febrero','Marzo','Abril','Mayo','Junio',
           'Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre']
    try: y,n=m.split('-'); return f"{meses[int(n)-1]} {y}"
    except: return m
