USE gic_recovery;
GO

-- Agregar monto_maximo y monto_minimo al padrón
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID('padron_mensual') AND name='monto_maximo')
    ALTER TABLE padron_mensual ADD monto_maximo DECIMAL(18,2) NULL;

IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID('padron_mensual') AND name='monto_minimo')
    ALTER TABLE padron_mensual ADD monto_minimo DECIMAL(18,2) NULL;

-- Actualizar registros existentes de prueba
UPDATE padron_mensual SET 
    monto_maximo = saldo_total,
    monto_minimo = saldo_total * 0.20
WHERE monto_maximo IS NULL;

PRINT 'Columnas monto_maximo y monto_minimo agregadas al padrón.';
GO
