-- ================================================================
-- Sistema Recovery — Control de Condonaciones
-- Script 01: Crear base de datos y todas las tablas
-- Ejecutar conectado al servidor (sin seleccionar BD aún)
-- ================================================================

IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'gic_recovery')
    CREATE DATABASE gic_recovery;
GO

USE gic_recovery;
GO

-- ──────────────────────────────────────────────────────────────
-- USUARIOS
-- ──────────────────────────────────────────────────────────────
IF OBJECT_ID('usuarios','U') IS NULL
CREATE TABLE usuarios (
    id              INT IDENTITY(1,1) PRIMARY KEY,
    username        VARCHAR(50)   NOT NULL UNIQUE,
    password        VARCHAR(255)  NOT NULL,
    rol             VARCHAR(20)   NOT NULL CHECK (rol IN ('gestor','supervisor')),
    nombre_completo VARCHAR(120)  NOT NULL,
    activo          BIT           NOT NULL DEFAULT 1,
    creado_en       DATETIME2     NOT NULL DEFAULT GETDATE()
);
GO

-- ──────────────────────────────────────────────────────────────
-- PADRÓN MENSUAL (carga del supervisor, ~1.5M filas)
-- ──────────────────────────────────────────────────────────────
IF OBJECT_ID('padron_mensual','U') IS NULL
CREATE TABLE padron_mensual (
    id              BIGINT IDENTITY(1,1) PRIMARY KEY,
    cu              VARCHAR(30)   NOT NULL,
    cj              VARCHAR(30)   NULL,
    nombre_cliente  VARCHAR(150)  NOT NULL,
    producto        VARCHAR(80)   NULL,
    saldo_total     DECIMAL(18,2) NOT NULL DEFAULT 0,
    dias_mora       INT           NULL,
    mes_carga       CHAR(7)       NOT NULL,   -- YYYY-MM
    subido_por      INT           NOT NULL REFERENCES usuarios(id),
    lote_id         UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID(),
    cargado_en      DATETIME2     NOT NULL DEFAULT GETDATE()
);
CREATE INDEX IX_padron_cu  ON padron_mensual(cu,  mes_carga);
CREATE INDEX IX_padron_cj  ON padron_mensual(cj,  mes_carga);
CREATE INDEX IX_padron_mes ON padron_mensual(mes_carga);
GO

-- ──────────────────────────────────────────────────────────────
-- CAMPAÑAS
-- ──────────────────────────────────────────────────────────────
IF OBJECT_ID('campanas','U') IS NULL
CREATE TABLE campanas (
    id              INT IDENTITY(1,1) PRIMARY KEY,
    nombre          VARCHAR(150)  NOT NULL,
    descripcion     NVARCHAR(500) NULL,
    monto_minimo    DECIMAL(18,2) NOT NULL DEFAULT 0,
    fecha_inicio    DATE          NOT NULL,
    fecha_fin       DATE          NOT NULL,
    activa          BIT           NOT NULL DEFAULT 1,
    creado_por      INT           NOT NULL REFERENCES usuarios(id),
    creado_en       DATETIME2     NOT NULL DEFAULT GETDATE()
);
GO

-- ──────────────────────────────────────────────────────────────
-- SOLICITUDES DE EXCEPCIÓN / CONDONACIÓN
-- ──────────────────────────────────────────────────────────────
IF OBJECT_ID('solicitudes','U') IS NULL
CREATE TABLE solicitudes (
    id                    INT IDENTITY(1,1) PRIMARY KEY,
    -- Identificadores del cliente
    cu                    VARCHAR(30)   NOT NULL,
    cj                    VARCHAR(30)   NULL,
    nombre_cliente        VARCHAR(150)  NOT NULL,
    producto              VARCHAR(80)   NULL,
    saldo_total           DECIMAL(18,2) NOT NULL DEFAULT 0,
    dias_mora             INT           NULL,
    -- Campaña y montos
    campana_id            INT           NOT NULL REFERENCES campanas(id),
    monto_minimo_camp     DECIMAL(18,2) NOT NULL,  -- snapshot al registrar
    pago_realizado        DECIMAL(18,2) NOT NULL DEFAULT 0,
    monto_a_condonar      DECIMAL(18,2) NOT NULL DEFAULT 0,
    -- Columna calculada: 1 = pago cumple, 0 = no cumple
    pago_conforme         AS (CASE WHEN pago_realizado >= monto_minimo_camp THEN 1 ELSE 0 END) PERSISTED,
    diferencia_pago       AS (pago_realizado - monto_minimo_camp) PERSISTED,
    -- Quién y cuándo
    gestor_id             INT           NOT NULL REFERENCES usuarios(id),
    estado                VARCHAR(20)   NOT NULL DEFAULT 'Borrador'
                          CHECK (estado IN ('Borrador','Enviado','Aprobado','Rechazado','Observado')),
    observacion_gestor    NVARCHAR(500) NULL,
    -- Resolución del supervisor
    resuelto_por          INT           NULL REFERENCES usuarios(id),
    comentario_resolucion NVARCHAR(500) NULL,
    -- Timestamps
    fecha_creacion        DATETIME2     NOT NULL DEFAULT GETDATE(),
    fecha_envio           DATETIME2     NULL,
    fecha_resolucion      DATETIME2     NULL,
    -- Mes de referencia del padrón
    mes_referencia        CHAR(7)       NULL
);
CREATE INDEX IX_sol_gestor  ON solicitudes(gestor_id);
CREATE INDEX IX_sol_estado  ON solicitudes(estado);
CREATE INDEX IX_sol_campana ON solicitudes(campana_id);
CREATE INDEX IX_sol_cu      ON solicitudes(cu);
CREATE INDEX IX_sol_fecha   ON solicitudes(fecha_creacion);
CREATE INDEX IX_sol_conf    ON solicitudes(pago_conforme);
GO

-- ──────────────────────────────────────────────────────────────
-- HISTORIAL DE ESTADOS (trazabilidad completa)
-- ──────────────────────────────────────────────────────────────
IF OBJECT_ID('historial_solicitudes','U') IS NULL
CREATE TABLE historial_solicitudes (
    id              INT IDENTITY(1,1) PRIMARY KEY,
    solicitud_id    INT           NOT NULL REFERENCES solicitudes(id),
    estado_anterior VARCHAR(20)   NULL,
    estado_nuevo    VARCHAR(20)   NOT NULL,
    comentario      NVARCHAR(500) NULL,
    usuario_id      INT           NOT NULL REFERENCES usuarios(id),
    fecha_hora      DATETIME2     NOT NULL DEFAULT GETDATE()
);
GO

-- ──────────────────────────────────────────────────────────────
-- CARGAS DE PADRÓN (registro de archivos subidos)
-- ──────────────────────────────────────────────────────────────
IF OBJECT_ID('cargas_padron','U') IS NULL
CREATE TABLE cargas_padron (
    id              INT IDENTITY(1,1) PRIMARY KEY,
    supervisor_id   INT           NOT NULL REFERENCES usuarios(id),
    nombre_archivo  VARCHAR(255)  NOT NULL,
    ruta_archivo    VARCHAR(500)  NOT NULL,
    mes_carga       CHAR(7)       NOT NULL,
    total_filas     INT           NOT NULL DEFAULT 0,
    filas_ok        INT           NOT NULL DEFAULT 0,
    filas_error     INT           NOT NULL DEFAULT 0,
    estado          VARCHAR(20)   NOT NULL DEFAULT 'procesando'
                    CHECK (estado IN ('procesando','completado','error')),
    mensaje_error   NVARCHAR(500) NULL,
    fecha_inicio    DATETIME2     NOT NULL DEFAULT GETDATE(),
    fecha_fin       DATETIME2     NULL
);
GO

-- ──────────────────────────────────────────────────────────────
-- BITÁCORA DE AUDITORÍA
-- ──────────────────────────────────────────────────────────────
IF OBJECT_ID('bitacora','U') IS NULL
CREATE TABLE bitacora (
    id          BIGINT IDENTITY(1,1) PRIMARY KEY,
    usuario_id  INT           NOT NULL REFERENCES usuarios(id),
    accion      VARCHAR(80)   NOT NULL,
    detalle     NVARCHAR(800) NULL,
    tabla_ref   VARCHAR(50)   NULL,
    id_ref      VARCHAR(50)   NULL,
    ip          VARCHAR(45)   NULL,
    fecha_hora  DATETIME2     NOT NULL DEFAULT GETDATE()
);
CREATE INDEX IX_bit_usuario ON bitacora(usuario_id);
CREATE INDEX IX_bit_fecha   ON bitacora(fecha_hora);
GO

PRINT 'Todas las tablas creadas correctamente en gic_recovery.';
