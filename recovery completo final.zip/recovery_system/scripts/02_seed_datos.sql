-- ================================================================
-- Sistema Recovery — Script 02: Datos iniciales
-- Gestores reales de Interbank Recovery
-- ================================================================
USE gic_recovery;
GO

-- ──────────────────────────────────────────────────────────────
-- LIMPIAR USUARIOS ANTERIORES
-- ──────────────────────────────────────────────────────────────
DELETE FROM bitacora;
DELETE FROM historial_solicitudes;
DELETE FROM solicitudes;
DELETE FROM cargas_padron;
DELETE FROM padron_mensual;
DELETE FROM campanas;
DELETE FROM usuarios;
GO

-- ──────────────────────────────────────────────────────────────
-- SUPERVISOR
-- ──────────────────────────────────────────────────────────────
INSERT INTO usuarios (username, password, rol, nombre_completo) VALUES
('B42172', '123456', 'supervisor', 'Zevallos Durand, Grethel');
GO

-- ──────────────────────────────────────────────────────────────
-- GESTORES (username = código, password = 123456)
-- ──────────────────────────────────────────────────────────────
INSERT INTO usuarios (username, password, rol, nombre_completo) VALUES
('B13440', '123456', 'gestor', 'Pantaleon Potosino, Karim Gisette'),
('B39696', '123456', 'gestor', 'Santi Migo, Maria Angelica'),
('B41875', '123456', 'gestor', 'Ferrer Cortez, Luz Milena'),
('B41585', '123456', 'gestor', 'Flores Sanez, Carol Elena'),
('B13443', '123456', 'gestor', 'Gastulo Lopez, German Gabriel'),
('B42256', '123456', 'gestor', 'Cruz Gonzales, Daysi Marianella'),
('B42788', '123456', 'gestor', 'Gastelu Peccalaico, Jessica Janeth'),
('B43398', '123456', 'gestor', 'Maribel Coyca'),
('B45679', '123456', 'gestor', 'Alejandra Patricia Narro Villanueva'),
('B45677', '123456', 'gestor', 'Jacqueline Margot Garcia Enriquez'),
('B46499', '123456', 'gestor', 'Javier Peña Chavez'),
('B46502', '123456', 'gestor', 'Susan Yauri Carreño'),
('B37445', '123456', 'gestor', 'Flores Pozu, Angela Denisse'),
('B19034', '123456', 'gestor', 'Livia Pajuelo, Margarita'),
('B19902', '123456', 'gestor', 'Tavara Rodriguez, Carolina'),
('B24275', '123456', 'gestor', 'Rodriguez Rojas, Jannet Lorena');
GO

-- ──────────────────────────────────────────────────────────────
-- CAMPAÑAS DE EJEMPLO
-- ──────────────────────────────────────────────────────────────
INSERT INTO campanas (nombre, descripcion, monto_minimo, fecha_inicio, fecha_fin, creado_por)
SELECT 'Recovery TC Agosto 2026',
       'Campaña Recovery Tarjeta de Crédito — Agosto 2026',
       500.00, '2026-08-01', '2026-08-31', id
FROM usuarios WHERE username = 'B42172';

INSERT INTO campanas (nombre, descripcion, monto_minimo, fecha_inicio, fecha_fin, creado_por)
SELECT 'Recovery PP Agosto 2026',
       'Campaña Recovery Préstamo Personal — Agosto 2026',
       300.00, '2026-08-01', '2026-08-31', id
FROM usuarios WHERE username = 'B42172';
GO

PRINT '====================================================';
PRINT 'Datos iniciales insertados correctamente:';
PRINT '  1 supervisora: Zevallos Durand, Grethel (B42172)';
PRINT '  16 gestores con codigo B como username';
PRINT '  Contraseña de todos: 123456';
PRINT '  2 campañas: Recovery TC y Recovery PP Agosto 2026';
PRINT '====================================================';
