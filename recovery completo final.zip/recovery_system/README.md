# Recovery — Sistema de Control de Condonaciones
### Interbank · Área de Cobranzas Recovery

---

## Descripción del proyecto

Sistema web que digitaliza y controla el proceso de solicitudes de condonación,
incorporando un **control preventivo** que bloquea el registro cuando el pago
del cliente no cumple el mínimo requerido por la campaña vigente.

**Objetivo:** eliminar el riesgo operacional de enviar a condonar cuentas cuyo
pago no cumple la condición mínima, evitando pérdidas, reprocesos y gasto
administrativo para el banco.

---

## Estructura del proyecto

```
recovery_system/
├── run.py                        ← Punto de entrada
├── requirements.txt
├── uploads/                      ← Archivos cargados (auto-creada)
│   ├── cargas/                   ← Excel del padrón mensual
│   └── exports/                  ← Exportaciones generadas
├── app/
│   ├── __init__.py               ← Factory Flask
│   ├── config.py                 ← Configuración SQL Server
│   ├── database.py               ← Toda la capa de datos (pyodbc)
│   ├── auth.py                   ← Decoradores de autenticación
│   ├── utils.py                  ← Leer Excel, exportar, helpers
│   ├── routes_gestor.py          ← Rutas perfil Gestor
│   ├── routes_supervisor.py      ← Rutas perfil Supervisor
│   ├── static/
│   │   ├── css/style.css
│   │   └── js/main.js
│   └── templates/
│       ├── base.html             ← Sidebar Interbank
│       ├── login.html
│       ├── ges_dashboard.html    ← Inicio del gestor
│       ├── ges_form.html         ← Formulario Excepción/Condonación
│       ├── ges_lista.html        ← Mis solicitudes
│       ├── detalle.html          ← Vista detalle (compartida)
│       ├── sup_dashboard.html    ← Dashboard gerencial con KPIs
│       ├── sup_solicitudes.html  ← Tabla con alertas en rojo
│       ├── sup_campanas.html     ← Gestión de campañas
│       ├── sup_padron.html       ← Carga del padrón mensual
│       └── sup_bitacora.html     ← Auditoría completa
└── scripts/
    ├── 01_crear_bd_y_tablas.sql  ← Crear BD + 6 tablas
    └── 02_seed_datos.sql         ← 18 usuarios + campañas + padrón demo
```

---

## Instalación paso a paso

### 1. Prerequisitos
- Python 3.9+
- SQL Server Express (o superior)
- ODBC Driver 17 for SQL Server

### 2. Instalar dependencias Python
```bash
pip install -r requirements.txt
```

### 3. Crear la base de datos en SSMS
Abre SQL Server Management Studio y ejecuta en orden:
```sql
-- Paso 1: Crear BD y tablas
-- Ejecuta: scripts/01_crear_bd_y_tablas.sql

-- Paso 2: Insertar datos iniciales
-- Ejecuta: scripts/02_seed_datos.sql
```

### 4. Configurar la conexión
Edita `app/config.py`:
```python
# Para tu casa:
DB_SERVER   = r'localhost\SQLEXPRESS'
DB_DATABASE = 'gic_recovery'
DB_TRUSTED  = 'yes'   # Windows Authentication

# Para el trabajo:
DB_SERVER   = r's528vp04\bdt'
DB_DATABASE = 'gic_recovery'   # o el nombre que elijas
```

### 5. Ejecutar
```bash
python run.py
```
Abre: **http://localhost:5000**

---

## Credenciales de acceso

| Usuario      | Contraseña  | Rol        |
|-------------|-------------|-----------|
| supervisor  | super2024   | Supervisor |
| gestor01    | g01pass     | Gestor     |
| gestor02    | g02pass     | Gestor     |
| ...         | ...         | ...        |
| gestor17    | g17pass     | Gestor     |

---

## Tablas en la base de datos

| Tabla                  | Descripción |
|------------------------|-------------|
| `usuarios`             | 18 usuarios con roles |
| `padron_mensual`       | Carga mensual del supervisor (~1.5M filas) |
| `campanas`             | Campañas con monto mínimo requerido |
| `solicitudes`          | Solicitudes de los gestores |
| `historial_solicitudes`| Trazabilidad de cambios de estado |
| `cargas_padron`        | Registro de archivos Excel subidos |
| `bitacora`             | Auditoría de todas las acciones |

---

## Flujo del sistema

### Supervisor (inicio de mes)
1. Entra a **Cargar padrón** → sube el Excel con ~1.5M cuentas
2. Crea las **campañas** del mes con su monto mínimo requerido
3. Monitorea el **Dashboard gerencial** con KPIs en tiempo real

### Gestor (operación diaria)
1. Va a **Nueva solicitud** → ingresa CU y CJ
2. El sistema busca la cuenta en el padrón y **autocompleta**: cliente, producto, saldo, días mora
3. Selecciona la **campaña**, ingresa el **pago realizado** y el **monto a condonar**
4. El panel derecho valida en tiempo real:
   - ✅ **Pago conforme**: puede enviar la solicitud
   - 🔴 **Pago menor**: botón bloqueado, no puede enviar
5. Guarda como borrador o envía directamente

### Supervisor (revisión)
1. Ve en **Solicitudes** todas las filas — **rojo** = pago menor al mínimo
2. Para cada solicitud Enviada puede: **Aprobar / Rechazar / Observar**
3. Todo queda en el **historial** con nombre del gestor, fecha y hora
4. **Exporta a Excel** para exportación a condonación (solo las aprobadas)
5. Revisa la **bitácora** para auditoría completa

---

## Indicadores gerenciales (Dashboard)

- Total solicitudes
- Pendientes de revisión
- Aprobadas / Rechazadas / Observadas
- **Alertas de monto** (pago < mínimo campaña)
- **Monto condonado** (total aprobado)
- **Monto recuperado** (pagos recibidos)
- **Pérdidas evitadas** (control preventivo)
- Monto condonado por campaña (barras)
