"""
Sistema web interno - Flask + SQL Server
Autenticación Windows (Trusted Connection)
"""

import os
import threading
import time
import json
from contextlib import contextmanager
from functools import wraps
from io import BytesIO
import pyodbc
import pandas as pd
from flask import (
    Flask, render_template, request, redirect,
    url_for, session, jsonify, Response, stream_with_context
)  
# ─────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────
app = Flask(__name__)
app.config['SESSION_COOKIE_NAME'] = 'sesion_app_2'
app.secret_key = os.environ.get("SECRET_KEY", "El_Inmortal_Jean")
app.config["MAX_CONTENT_LENGTH"] = 100 * 1024 * 1024  # 100 MB
DB_SERVER   = os.environ.get("DB_SERVER",   r"s528vp04\bdt")
DB_DATABASE = os.environ.get("DB_DATABASE", "gic")
T_USUARIOS     = "cob_tr_p1_usuarios_web"
T_DATA         = "cob_tr_p1_data_web"
T_CONFIG       = "cob_tr_p1_config_col"
T_CTRL         = "cob_tr_p1_ctrl_actualizaciones"
T_GESTIONES    = "cob_tr_p1_gestiones" 
T_TIPI         = "cob_tr_p1_tipi_web"
MANDATORY_COLS = {"cu", "cj"}
DB_MANAGED_COLS = {"telefono"}
CHUNK_SIZE     = 10_000
MAX_UPDATE_USES = 5
DEFAULT_COLS = [
    {"col": "cu",              "label": "CU",          "visible": True, "is_table": False},
    {"col": "nro_documento",   "label": "NRO. DOC.",   "visible": True, "is_table": False},
    {"col": "cj",              "label": "CJ",          "visible": True, "is_table": True},
    {"col": "cliente",         "label": "CLIENTE",      "visible": True, "is_table": False},
    {"col": "grupo_producto",  "label": "PRODUCTO",     "visible": True, "is_table": True},
    {"col": "capital",         "label": "CAPITAL",      "visible": True, "is_table": True},
    {"col": "deuda_total",     "label": "DEUDA TOTAL", "visible": True, "is_table": True},
    {"col": "estudio",         "label": "ESTUDIO",      "visible": True, "is_table": False},
]
MAX_CONNECTIONS = 3
_sem = threading.BoundedSemaphore(MAX_CONNECTIONS)
# ─────────────────────────────────────────
# DB – context manager
# ─────────────────────────────────────────
def _conn_str():
    return (
        f"DRIVER={{ODBC Driver 17 for SQL Server}};"
        f"SERVER={DB_SERVER};DATABASE={DB_DATABASE};"
        f"Trusted_Connection=yes;"
    )
@contextmanager
def db_conn():
    _sem.acquire()
    conn = None
    try:
        conn = pyodbc.connect(_conn_str(), timeout=10)
        conn.autocommit = False
        yield conn
    except Exception:
        if conn is not None:
            try: conn.rollback()
            except Exception: pass
        raise
    finally:
        if conn is not None:
            try: conn.close()
            except Exception: pass
        _sem.release()
def get_table_columns(table_name):
    with db_conn() as conn:
        cur = conn.cursor()
        cur.execute(
            "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS "
            "WHERE TABLE_NAME = ? ORDER BY ORDINAL_POSITION",
            (table_name,)
        )
        return [r[0].lower() for r in cur.fetchall()]
def get_table_col_types(table_name):
    with db_conn() as conn:
        cur = conn.cursor()
        cur.execute(
            "SELECT COLUMN_NAME, DATA_TYPE "
            "FROM INFORMATION_SCHEMA.COLUMNS "
            "WHERE TABLE_NAME = ? ORDER BY ORDINAL_POSITION",
            (table_name,)
        )
        return {r[0].lower(): r[1].lower() for r in cur.fetchall()}
_SQL_INT_TYPES   = {"int", "bigint", "smallint", "tinyint"}
_SQL_FLOAT_TYPES = {"float", "real", "decimal", "numeric", "money", "smallmoney"}
_SQL_DATE_TYPES  = {"date", "datetime", "datetime2", "smalldatetime", "datetimeoffset", "time"}
def cast_value(val, sql_type):
    if val is None:
        return None
    s = str(val).strip()
    if s == "" or s.lower() in ("nan", "none", "null", "nat"):
        return None
    if sql_type in _SQL_INT_TYPES:
        try:
            return int(float(s))
        except (ValueError, OverflowError):
            return None
    if sql_type in _SQL_FLOAT_TYPES:
        s2 = s.replace(",", ".")
        try:
            return float(s2)
        except ValueError:
            return None
    if sql_type in _SQL_DATE_TYPES:
        return s if s else None
    return s
# ─────────────────────────────────────────
# CONFIG DE COLUMNAS
# ─────────────────────────────────────────
def ensure_config_table():
    with db_conn() as conn:
        cur = conn.cursor()
        cur.execute(f"""
            IF NOT EXISTS (
                SELECT 1 FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_NAME = '{T_CONFIG}'
            )
            CREATE TABLE {T_CONFIG} (
                id       INT IDENTITY(1,1) PRIMARY KEY,
                col_key  NVARCHAR(100) NOT NULL,
                label    NVARCHAR(100) NOT NULL,
                visible  BIT NOT NULL DEFAULT 1,
                orden    INT NOT NULL DEFAULT 0,
                is_table BIT NOT NULL DEFAULT 0
            )
        """)
        conn.commit()
        # Migración silenciosa
        cur.execute(f"""
            IF NOT EXISTS (
                SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = '{T_CONFIG}' AND COLUMN_NAME = 'is_table'
            )
            ALTER TABLE {T_CONFIG} ADD is_table BIT NOT NULL DEFAULT 0
        """)
        conn.commit()
def ensure_ctrl_table():
    with db_conn() as conn:
        cur = conn.cursor()
        cur.execute(f"""
            IF NOT EXISTS (
                SELECT 1 FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_NAME = '{T_CTRL}'
            )
            CREATE TABLE {T_CTRL} (
                id         INT IDENTITY(1,1) PRIMARY KEY,
                evento     NVARCHAR(50)  NOT NULL,
                usuario    NVARCHAR(100) NOT NULL,
                detalle    INT           NULL,
                ts         DATETIME      NOT NULL DEFAULT GETDATE()
            )
        """)
        conn.commit()
        cur.execute(f"""
            IF NOT EXISTS (
                SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = '{T_CTRL}' AND COLUMN_NAME = 'detalle'
            )
            ALTER TABLE {T_CTRL} ADD detalle INT NULL
        """)
        conn.commit()
def load_col_config():
    try:
        ensure_config_table()
        with db_conn() as conn:
            cur = conn.cursor()
            cur.execute(
                f"SELECT col_key, label, visible, orden, is_table FROM {T_CONFIG} ORDER BY orden"
            )
            rows = cur.fetchall()
        if rows:
            return [{"col": r[0], "label": r[1], "visible": bool(r[2]), "orden": r[3], "is_table": bool(r[4])}
                    for r in rows]
        save_col_config(DEFAULT_COLS)
        return [dict(c, orden=i) for i, c in enumerate(DEFAULT_COLS)]
    except Exception:
        return [dict(c, orden=i) for i, c in enumerate(DEFAULT_COLS)]
def save_col_config(cols):
    with db_conn() as conn:
        cur = conn.cursor()
        cur.execute(f"DELETE FROM {T_CONFIG}")
        for i, c in enumerate(cols):
            cur.execute(
                f"INSERT INTO {T_CONFIG} (col_key, label, visible, orden, is_table) VALUES (?,?,?,?,?)",
                (c["col"], c["label"], 1 if c.get("visible", True) else 0, i, 1 if c.get("is_table", False) else 0)
            )
        conn.commit()
# ─────────────────────────────────────────
# TIPO / RESULTADO DE GESTIÓN  (NUEVO)
# ─────────────────────────────────────────
T_TIPO_GESTION      = "cob_tr_p1_tipo_gestion"
T_RESULTADO_GESTION = "cob_tr_p1_resultado_gestion"

def ensure_tipo_resultado_tables():
    with db_conn() as conn:
        cur = conn.cursor()

        cur.execute(f"""
            IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = '{T_TIPO_GESTION}')
            CREATE TABLE {T_TIPO_GESTION} (
                id     INT IDENTITY(1,1) PRIMARY KEY,
                valor  NVARCHAR(100) NOT NULL,
                orden  INT NOT NULL DEFAULT 0
            )
        """)
        conn.commit()
        cur.execute(f"SELECT COUNT(*) FROM {T_TIPO_GESTION}")
        if cur.fetchone()[0] == 0:
            for i, v in enumerate(["INTERNO", "EXTERNO", "VENTA CARTERA"]):
                cur.execute(f"INSERT INTO {T_TIPO_GESTION} (valor, orden) VALUES (?,?)", (v, i))
            conn.commit()

        cur.execute(f"""
            IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = '{T_RESULTADO_GESTION}')
            CREATE TABLE {T_RESULTADO_GESTION} (
                id     INT IDENTITY(1,1) PRIMARY KEY,
                valor  NVARCHAR(100) NOT NULL,
                orden  INT NOT NULL DEFAULT 0
            )
        """)
        conn.commit()
        cur.execute(f"SELECT COUNT(*) FROM {T_RESULTADO_GESTION}")
        if cur.fetchone()[0] == 0:
            for i, v in enumerate(["INFORMACIÓN","FRACCIONAMIENTO", "PROMESA DE PAGO", "VOLVER A LLAMAR", "OTROS"]):
                cur.execute(f"INSERT INTO {T_RESULTADO_GESTION} (valor, orden) VALUES (?,?)", (v, i))
            conn.commit()

        # Agrega las columnas nuevas a la tabla de gestiones si no existen
        cur.execute(f"""
            IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
                           WHERE TABLE_NAME='{T_GESTIONES}' AND COLUMN_NAME='tipo_clasificacion')
            ALTER TABLE {T_GESTIONES} ADD tipo_clasificacion NVARCHAR(100) NULL
        """)
        conn.commit()
        cur.execute(f"""
            IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
                           WHERE TABLE_NAME='{T_GESTIONES}' AND COLUMN_NAME='resultado_clasificacion')
            ALTER TABLE {T_GESTIONES} ADD resultado_clasificacion NVARCHAR(100) NULL
        """)
        conn.commit()

def load_tipo_gestion():
    ensure_tipo_resultado_tables()
    with db_conn() as conn:
        cur = conn.cursor()
        cur.execute(f"SELECT valor FROM {T_TIPO_GESTION} ORDER BY orden")
        return [r[0] for r in cur.fetchall()]

def load_resultado_gestion():
    ensure_tipo_resultado_tables()
    with db_conn() as conn:
        cur = conn.cursor()
        cur.execute(f"SELECT valor FROM {T_RESULTADO_GESTION} ORDER BY orden")
        return [r[0] for r in cur.fetchall()]

def save_tipo_gestion(valores):
    ensure_tipo_resultado_tables()
    with db_conn() as conn:
        cur = conn.cursor()
        cur.execute(f"DELETE FROM {T_TIPO_GESTION}")
        for i, v in enumerate(valores):
            cur.execute(f"INSERT INTO {T_TIPO_GESTION} (valor, orden) VALUES (?,?)", (v, i))
        conn.commit()

def save_resultado_gestion(valores):
    ensure_tipo_resultado_tables()
    with db_conn() as conn:
        cur = conn.cursor()
        cur.execute(f"DELETE FROM {T_RESULTADO_GESTION}")
        for i, v in enumerate(valores):
            cur.execute(f"INSERT INTO {T_RESULTADO_GESTION} (valor, orden) VALUES (?,?)", (v, i))
        conn.commit()
# ─────────────────────────────────────────
# TELÉFONOS — lógica de BD
# ─────────────────────────────────────────
SQL_POPULATE_TELEFONO = f"""
UPDATE a
SET    a.telefono = b.TELEFONO
FROM   {T_DATA} a
INNER JOIN (
    SELECT CU, TELEFONO
    FROM (
        SELECT *,
               ROW_NUMBER() OVER (
                   PARTITION BY CU
                   ORDER BY ORDEN_FINAL, FECHA DESC
              ) AS RN
        FROM COB_TR_SCORE_TELEFONOS_V4
    ) ranked
    WHERE RN = 1
) b ON a.CU = b.CU
"""
def populate_telefono(conn):
    cur = conn.cursor()
    cur.execute(SQL_POPULATE_TELEFONO)
    rows_affected = cur.rowcount
    conn.commit()
    return rows_affected
def get_tel_update_count():
    try:
        ensure_ctrl_table()
        with db_conn() as conn:
            cur = conn.cursor()
            cur.execute(
                f"SELECT COUNT(*) FROM {T_CTRL} WHERE evento = 'update_tel'"
            )
            return cur.fetchone()[0]
    except Exception:
        return 0
def register_event(evento: str, usuario: str, detalle: int = None):
    ensure_ctrl_table()
    with db_conn() as conn:
        cur = conn.cursor()
        cur.execute(
            f"INSERT INTO {T_CTRL} (evento, usuario, detalle) VALUES (?, ?, ?)",
            (evento, usuario, detalle)
        )
        conn.commit()
def reset_tel_counter():
    try:
        ensure_ctrl_table()
        with db_conn() as conn:
            cur = conn.cursor()
            cur.execute(f"DELETE FROM {T_CTRL} WHERE evento = 'update_tel'")
            conn.commit()
    except Exception:
        pass
# ─────────────────────────────────────────
# AUTH
# ─────────────────────────────────────────
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "usuario_id" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated
def role_required(role):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if "usuario_id" not in session:
                return redirect(url_for("login"))
            if session.get("rol") != role:
                return redirect(url_for("index"))
            return f(*args, **kwargs)
        return decorated
    return decorator
def sse(event, data):
    return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"
# ─────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────
@app.route("/")
def index():
    if "usuario_id" not in session:
        return redirect(url_for("login"))
    rol = session.get("rol")
    if rol == 1: return redirect(url_for("dashboard_carga"))
    if rol == 2: return redirect(url_for("dashboard_consultas"))
    return redirect(url_for("login"))
@app.route("/login", methods=["GET", "POST"])
def login():
    if "usuario_id" in session:
        return redirect(url_for("index"))
    error = None
    if request.method == "POST":
        usuario    = request.form.get("usuario", "").strip()
        contrasena = request.form.get("contrasena", "").strip()
        try:
            with db_conn() as conn:
                cur = conn.cursor()
                cur.execute(
                    f"SELECT usuario, contrasena, nombre, rol "
                    f"FROM {T_USUARIOS} WHERE usuario = ?", (usuario,)
                )
                row = cur.fetchone()
        except Exception as e:
            return render_template("login.html", error=f"Error de conexión: {e}")
        if row and row[1] == contrasena:
            session["usuario_id"] = row[0]
            session["nombre"]     = row[2]
            session["rol"]        = int(row[3]) if row[3] is not None else 1
            return redirect(url_for("index"))
        error = "Usuario o contraseña incorrectos."
    return render_template("login.html", error=error)
@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))
@app.route("/dashboard", methods=["GET"])
@role_required(1)
def dashboard_carga():
    col_config    = load_col_config()
    tel_usos      = get_tel_update_count()
    tel_restantes = max(0, MAX_UPDATE_USES - tel_usos)
    return render_template(
        "dashboard.html",
        nombre=session.get("nombre"),
        rol=session.get("rol"),
        col_config=col_config,
        tel_usos=tel_usos,
        tel_restantes=tel_restantes,
        tel_max=MAX_UPDATE_USES,
    )
@app.route("/api/stats", methods=["GET"])
@role_required(1)
def api_stats():
    try:
        ensure_ctrl_table()
        with db_conn() as conn:
            cur = conn.cursor()
            cur.execute(f"SELECT COUNT(*) FROM {T_DATA}")
            total = cur.fetchone()[0]
            cur.execute(f"""
                SELECT TOP 1
                    c.ts AS ts_peru,
                    c.detalle,
                    ISNULL(u.nombre, c.usuario) AS nombre_display
                FROM {T_CTRL} c
                LEFT JOIN {T_USUARIOS} u ON u.usuario = c.usuario
                WHERE c.evento = 'carga'
                ORDER BY c.ts DESC
            """)
            row = cur.fetchone()
        ultima_carga   = None
        ultima_filas   = None
        ultimo_usuario = None
        if row:
            ultima_carga   = row[0].strftime("%d/%m/%Y %H:%M") if row[0] else None
            ultima_filas   = row[1]
            ultimo_usuario = row[2]
        return jsonify({
            "ok":            True,
            "total_registros": total,
            "ultima_carga":   ultima_carga,
            "ultima_filas":   ultima_filas,
            "ultimo_usuario": ultimo_usuario,
        })
    except Exception as e:
        return jsonify({"ok": False, "msg": str(e)}), 500
@app.route("/api/hojas", methods=["POST"])
@role_required(1)
def api_hojas():
    if "archivo" not in request.files:
        return jsonify({"ok": False, "msg": "No se recibió archivo."}), 400
    file = request.files["archivo"]
    filename = (file.filename or "").lower()
    if filename and not filename.endswith((".xlsx", ".xls")):
        return jsonify({"ok": False, "msg": "Solo se aceptan archivos Excel (.xlsx / .xls)."}), 400
    try:
        raw = file.read()
        if not raw:
            return jsonify({"ok": False, "msg": "El archivo llegó vacío al servidor."}), 400
        xf = pd.ExcelFile(BytesIO(raw))
        sheet_names = xf.sheet_names
        if not sheet_names:
            return jsonify({"ok": False, "msg": "El archivo no contiene hojas."}), 400
        return jsonify({"ok": True, "hojas": sheet_names})
    except Exception as e:
        return jsonify({"ok": False, "msg": f"Error al leer el archivo: {e}"}), 400
@app.route("/api/col-config", methods=["GET"])
@role_required(1)
def api_get_col_config():
    return jsonify({"ok": True, "cols": load_col_config()})
@app.route("/api/sql-cols", methods=["GET"])
@role_required(1)
def api_sql_cols():
    try:
        cols = get_table_columns(T_DATA)
        return jsonify({"ok": True, "cols": cols})
    except Exception as e:
        return jsonify({"ok": False, "msg": str(e)}), 500
@app.route("/api/col-config", methods=["POST"])
@role_required(1)
def api_save_col_config():
    data = request.get_json(silent=True)
    if not data or "cols" not in data:
        return jsonify({"ok": False, "msg": "Payload inválido."}), 400
    try:
        save_col_config(data["cols"])
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"ok": False, "msg": str(e)}), 500
# ─────────────────────────────────────────
# API TIPO / RESULTADO DE GESTIÓN (NUEVO — admin, solo supervisor)
# ─────────────────────────────────────────
@app.route("/api/tipo-resultado-config", methods=["GET"])
@role_required(1)
def api_get_tipo_resultado_config():
    return jsonify({"ok": True, "tipos": load_tipo_gestion(), "resultados": load_resultado_gestion()})

@app.route("/api/tipo-resultado-config", methods=["POST"])
@role_required(1)
def api_save_tipo_resultado_config():
    data = request.get_json(silent=True) or {}
    tipos = data.get("tipos")
    resultados = data.get("resultados")
    if not isinstance(tipos, list) or not isinstance(resultados, list):
        return jsonify({"ok": False, "msg": "Payload inválido."}), 400
    try:
        save_tipo_gestion(tipos)
        save_resultado_gestion(resultados)
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"ok": False, "msg": str(e)}), 500
@app.route("/api/upload", methods=["POST"])
@role_required(1)
def api_upload():
    if "archivo" not in request.files:
        return jsonify({"ok": False, "msg": "No se recibió ningún archivo."}), 400
    file = request.files["archivo"]
    hoja = request.form.get("hoja", 0)
    if not file.filename.lower().endswith((".xlsx", ".xls")):
        return jsonify({"ok": False, "msg": "Solo se aceptan archivos Excel (.xlsx / .xls)."}), 400
    raw = file.read()
    usuario = session.get("usuario_id", "desconocido")
    
    def generate():
        yield sse("progress", {"step": 1, "msg": "Leyendo archivo Excel...", "pct": 5})
        try:
            sheet = int(hoja) if str(hoja).isdigit() else hoja
            df = pd.read_excel(BytesIO(raw), sheet_name=sheet, dtype=str,
                               keep_default_na=False, na_filter=False)
        except Exception as e:
            yield sse("error", {"msg": f"Error al leer el archivo: {e}"}); return
        total_rows = len(df)
        yield sse("progress", {"step": 1, "msg": f"Archivo leído: {total_rows:,} filas.", "pct": 10})
        yield sse("progress", {"step": 2, "msg": "Validando columnas...", "pct": 12})
        df.columns = [c.strip() for c in df.columns]
        df_cols_lower = {c.lower(): c for c in df.columns}
        for managed in DB_MANAGED_COLS:
            if managed in df_cols_lower:
                del df_cols_lower[managed]
        missing = MANDATORY_COLS - set(df_cols_lower.keys())
        if missing:
            yield sse("error", {"msg": f"Columnas obligatorias faltantes: "
                                       f"{', '.join(m.upper() for m in missing)}. Carga cancelada."}); return
        try:
            sql_cols      = get_table_columns(T_DATA)
            sql_col_types = get_table_col_types(T_DATA)
            sql_cols = [c for c in sql_cols if c not in DB_MANAGED_COLS]
        except Exception as e:
            yield sse("error", {"msg": f"Error al conectar con la BD: {e}"}); return
        cols_to_load  = [c for c in df_cols_lower if c in sql_cols]
        cols_excluded = [c for c in df_cols_lower if c not in sql_cols]
        if not cols_to_load:
            yield sse("error", {"msg": "Ninguna columna del archivo coincide con la tabla destino."}); return
        original_names = [df_cols_lower[c] for c in cols_to_load]
        df_load = df[original_names].copy()
        df_load.columns = cols_to_load
        col_types_ordered = [sql_col_types.get(c, "nvarchar") for c in cols_to_load]
        rows_all = [
            tuple(cast_value(row[i], col_types_ordered[i]) for i in range(len(cols_to_load)))
            for row in df_load.itertuples(index=False, name=None)
        ]
        yield sse("progress", {
            "step": 2, "pct": 15,
            "msg": f"Columnas válidas: {len(cols_to_load)} | Omitidas: {len(cols_excluded)}",
            "cols_excluidas": len(cols_excluded),
            "nombres_excluidas": [df_cols_lower[c] for c in cols_excluded],
        })
        yield sse("progress", {"step": 3, "msg": "Vaciando tabla destino (TRUNCATE)...", "pct": 18})
        placeholders = ", ".join(["?"] * len(cols_to_load))
        col_names    = ", ".join(cols_to_load)
        sql_insert   = f"INSERT INTO {T_DATA} ({col_names}) VALUES ({placeholders})"
        loaded  = 0
        t_start = time.time()
        try:
            with db_conn() as conn:
                cur = conn.cursor()
                cur.fast_executemany = True
                cur.execute(f"TRUNCATE TABLE {T_DATA}")
                conn.commit()
                reset_tel_counter()
                n_chunks = max(1, (total_rows + CHUNK_SIZE - 1) // CHUNK_SIZE)
                for i in range(n_chunks):
                    chunk = rows_all[i * CHUNK_SIZE: (i + 1) * CHUNK_SIZE]
                    cur.executemany(sql_insert, chunk)
                    conn.commit()
                    loaded += len(chunk)
                    elapsed  = time.time() - t_start
                    pct_data = loaded / total_rows
                    pct_ui   = 18 + int(pct_data * 72)
                    elapsed_str = (f"{int(elapsed//60)}m {int(elapsed%60)}s"
                                   if elapsed >= 60 else f"{int(elapsed)}s")
                    if pct_data > 0:
                        remaining = max(0, (elapsed / pct_data) - elapsed)
                        eta_str = (f"{int(remaining//60)}m {int(remaining%60)}s"
                                   if remaining >= 60 else f"{int(remaining)}s")
                    else:
                        eta_str = "—"
                    yield sse("progress", {
                        "step": 4, "pct": pct_ui,
                        "msg": f"Insertando... {loaded:,} / {total_rows:,} filas",
                        "loaded": loaded, "total": total_rows,
                        "elapsed": elapsed_str,
                        "eta": eta_str,
                    })
        except GeneratorExit:
            return
        except Exception as e:
            yield sse("error", {"msg": f"Error al cargar datos (fila ~{loaded}): {e}"}); return
        yield sse("progress", {
            "step": 4, "pct": 92,
            "msg": "Cruzando teléfonos con la tabla de scores...",
        })
        try:
            with db_conn() as conn:
                tel_rows = populate_telefono(conn)
            register_event("update_tel", usuario)
        except Exception as e:
            yield sse("warning", {"msg": f"Datos cargados pero no se pudieron cruzar teléfonos: {e}"})
            tel_rows = 0
        elapsed_total = time.time() - t_start
        try:
            register_event("carga", usuario, total_rows)
        except Exception:
            pass
        tel_usos      = get_tel_update_count()
        tel_restantes = max(0, MAX_UPDATE_USES - tel_usos)
        yield sse("done", {
            "total_filas":       total_rows,
            "cols_cargadas":     len(cols_to_load),
            "cols_excluidas":    len(cols_excluded),
            "nombres_excluidas": [df_cols_lower[c] for c in cols_excluded],
            "segundos":        round(elapsed_total, 1),
            "tel_rows":        tel_rows,
            "tel_usos":        tel_usos,
            "tel_restantes":   tel_restantes,
            "tel_max":         MAX_UPDATE_USES,
        })
    return Response(stream_with_context(generate()), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
@app.route("/api/actualizar-telefonos", methods=["POST"])
@role_required(1)
def api_actualizar_telefonos():
    usuario = session.get("usuario_id", "desconocido")
    try:
        usos = get_tel_update_count()
    except Exception as e:
        return jsonify({"ok": False, "msg": f"Error al verificar el contador: {e}"}), 500
    if usos >= MAX_UPDATE_USES:
        return jsonify({
            "ok": False,
            "msg": f"Límite alcanzado. Solo se permiten {MAX_UPDATE_USES} actualizaciones por ciclo de carga.",
            "tel_usos": usos,
            "tel_restantes": 0,
            "tel_max": MAX_UPDATE_USES,
        }), 429
    try:
        with db_conn() as conn:
            cur = conn.cursor()
            cur.execute(f"UPDATE {T_DATA} SET telefono = NULL")
            conn.commit()
            tel_rows = populate_telefono(conn)
        register_event("update_tel", usuario)
        usos_nuevo    = usos + 1
        tel_restantes = max(0, MAX_UPDATE_USES - usos_nuevo)
        return jsonify({
            "ok":             True,
            "tel_rows":      tel_rows,
            "tel_usos":      usos_nuevo,
            "tel_restantes": tel_restantes,
            "tel_max":       MAX_UPDATE_USES,
            "msg":           f"Teléfonos actualizados: {tel_rows:,} registros cruzados.",
        })
    except Exception as e:
        return jsonify({"ok": False, "msg": f"Error al actualizar teléfonos: {e}"}), 500
@app.route("/api/tel-status", methods=["GET"])
@role_required(1)
def api_tel_status():
    usos = get_tel_update_count()
    return jsonify({
        "ok":            True,
        "tel_usos":      usos,
        "tel_restantes": max(0, MAX_UPDATE_USES - usos),
        "tel_max":       MAX_UPDATE_USES,
    })
# ── DASHBOARD CONSULTAS (usuario 2) ─────────────────────────
@app.route("/consultas")
@role_required(2)
def dashboard_consultas():
    return render_template("consultas.html",
                           nombre=session.get("nombre"),
                           rol=session.get("rol"))
@app.route("/api/buscar", methods=["GET"])
@role_required(2)
def api_buscar():
    cu            = request.args.get("cu", "").strip()
    cj            = request.args.get("cj", "").strip()
    nro_documento = request.args.get("nro_documento", "").strip()
    page = max(1, int(request.args.get("page", 1)))
    size = 50
    if not cu and not cj and not nro_documento:
        return jsonify({"ok": False, "msg": "Ingresa al menos un criterio de búsqueda."}), 400
    conditions, params = [], []
    if cu:
        conditions.append("LOWER(CAST(cu AS NVARCHAR(MAX))) LIKE LOWER(?)")
        params.append(f"%{cu}%")
    if cj:
        conditions.append("LOWER(CAST(cj AS NVARCHAR(MAX))) LIKE LOWER(?)")
        params.append(f"%{cj}%")
    if nro_documento:
        conditions.append("LOWER(CAST(nro_documento AS NVARCHAR(MAX))) LIKE LOWER(?)")
        params.append(f"%{nro_documento}%")
    where  = " AND ".join(conditions)
    offset = (page - 1) * size
    
    col_config = load_col_config()
    visible_cols = [c for c in col_config if c["visible"]]
    
    with db_conn() as conn:
        cur = conn.cursor()
        cur.execute(
            "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS "
            "WHERE TABLE_NAME = ? ORDER BY ORDINAL_POSITION", (T_DATA,)
        )
        real_cols = {r[0].lower() for r in cur.fetchall()}
        has_nro_doc = "nro_documento" in real_cols
        if nro_documento and not has_nro_doc:
            return jsonify({"ok": False, "msg": "La columna nro_documento no existe en la tabla de datos."}), 400
        cur.execute(f"SELECT COUNT(*) FROM {T_DATA} WHERE {where}", params)
        total = cur.fetchone()[0]
        required = {"cu", "cj"}
        if has_nro_doc:
            required.add("nro_documento")
        fetch_set = {c["col"] for c in visible_cols} | required
        fetch_cols_real = [c for c in fetch_set if c in real_cols]
        ordered = []
        for must in ["cu", "cj"]:
            if must in fetch_cols_real:
                ordered.append(must)
        if has_nro_doc and "nro_documento" in fetch_cols_real:
            ordered.append("nro_documento")
        for c in fetch_cols_real:
            if c not in ordered:
                ordered.append(c)
        fetch_cols_real = ordered
        cols_str = ", ".join(fetch_cols_real) if fetch_cols_real else "cu, cj"
        cur.execute(
            f"SELECT {cols_str}, (SELECT COUNT(*) FROM {T_DATA} t2 WHERE t2.cu = {T_DATA}.cu AND t2.cu != '') AS __total_cu "
            f"FROM {T_DATA} WHERE {where} "
            f"ORDER BY (SELECT NULL) OFFSET ? ROWS FETCH NEXT ? ROWS ONLY",
            params + [offset, size]
        )
        rows = cur.fetchall()
        raw_data = [dict(zip(fetch_cols_real + ["__total_cu"], r)) for r in rows]
        
    result_rows = []
    for row in raw_data:
        entry = {}
        for c in visible_cols:
            key = c["col"]
            entry[c["label"]] = row.get(key, None)
            
        entry["_cu"] = row.get("cu", "")
        entry["_cj"] = row.get("cj", "")
        entry["__total_cu"] = row.get("__total_cu", 1)
        result_rows.append(entry)
        
    cols_def = [{"label": c["label"], "is_table": c.get("is_table", False)} for c in visible_cols]
    
    return jsonify({
        "ok": True, "total": total, "page": page,
        "size": size, "cols": cols_def, "rows": result_rows,
        "has_nro_doc": has_nro_doc,
    })
# ─────────────────────────────────────────
# /api/tipificaciones — AHORA DEVUELVE TIPO/RESULTADO (antes Grupo/Subgrupo)
# ─────────────────────────────────────────
@app.route("/api/tipificaciones", methods=["GET"])
@role_required(2)
def api_tipificaciones():
    try:
        tipos = load_tipo_gestion()
        resultados = load_resultado_gestion()
        return jsonify({"ok": True, "tipos": tipos, "resultados": resultados})
    except Exception as e:
        return jsonify({"ok": False, "msg": f"Error al cargar tipificaciones: {e}"}), 500
@app.route("/api/gestionar", methods=["POST"])
@role_required(2)
def api_gestionar():
    try:
        data = request.get_json(silent=True) or {}
        
        cu_raw = data.get("cu")
        cj_raw = data.get("cj")
        cu = str(cu_raw).strip() if cu_raw else ""
        cj = str(cj_raw).strip() if cj_raw else ""
        
        telefono_contacto = str(data.get("telefono_contacto", "")).strip()
        tipo_clasificacion = str(data.get("tipo_clasificacion", "")).strip()
        resultado_clasificacion = str(data.get("resultado_clasificacion", "")).strip()
        
        if not cu:
            return jsonify({"ok": False, "msg": "Falta el identificador CU."}), 400
        if not tipo_clasificacion or not resultado_clasificacion:
            return jsonify({"ok": False, "msg": "Es obligatorio seleccionar Tipo y Resultado."}), 400
            
        usuario = session.get("usuario_id", "desconocido")
        nombre = session.get("nombre", "Sin Nombre")
        
        cols = get_table_columns(T_DATA)
        cols_str = ", ".join(cols)
        
        if cj:
            where_clause = "cu = ? AND cj = ?"
            where_params = [cu, cj]
            tipo_gestion = 'CJ'
        else:
            where_clause = "cu = ?"
            where_params = [cu]
            tipo_gestion = 'CU'
            
        sql = f"""
            INSERT INTO {T_GESTIONES} ({cols_str}, usuario, nombre, fecha_gestion, tipo_gestion, telefono_contacto, tipo_clasificacion, resultado_clasificacion)
            SELECT {cols_str}, ?, ?, GETDATE(), ?, ?, ?, ?
            FROM {T_DATA}
            WHERE {where_clause}
        """
        
        params = [usuario, nombre, tipo_gestion, telefono_contacto, tipo_clasificacion, resultado_clasificacion] + where_params
        
        with db_conn() as conn:
            cur = conn.cursor()
            cur.execute(sql, params)
            conn.commit()
            registros = cur.rowcount
            
        msg = f"Se registró la gestión de {registros} producto(s)." if not cj else f"Se registró la gestión del CJ {cj}."
        return jsonify({"ok": True, "msg": msg, "registros": registros})
        
    except Exception as e:
        return jsonify({"ok": False, "msg": f"Error al registrar gestión: {e}"}), 500
@app.route("/api/gestiones", methods=["GET"])
@role_required(2)
def api_gestiones():
    cu = request.args.get("cu", "").strip()
    if not cu:
        return jsonify({"ok": False, "msg": "Falta el identificador CU."}), 400
    
    try:
        with db_conn() as conn:
            cur = conn.cursor()
            
            cur.execute(
                "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = ?", 
                (T_GESTIONES,)
            )
            exist_cols = {r[0].lower() for r in cur.fetchall()}
            
            cap_col = "capital" if "capital" in exist_cols else "NULL as capital"
            deuda_col = "deuda_total" if "deuda_total" in exist_cols else "NULL as deuda_total"
            tipo_col = "tipo_gestion" if "tipo_gestion" in exist_cols else "'CU' as tipo_gestion"
            prod_col = "grupo_producto" if "grupo_producto" in exist_cols else "NULL as grupo_producto"
            tipo_clas_col = "tipo_clasificacion" if "tipo_clasificacion" in exist_cols else "NULL as tipo_clasificacion"
            resultado_clas_col = "resultado_clasificacion" if "resultado_clasificacion" in exist_cols else "NULL as resultado_clasificacion"
            # Agregamos validación para el teléfono de contacto insertado
            tel_cont_col = "telefono_contacto" if "telefono_contacto" in exist_cols else "NULL as telefono_contacto"
            
            sql = f"""
                SELECT 
                    usuario, nombre, cu, cj, {cap_col}, {deuda_col}, telefono, 
                    CONVERT(VARCHAR(19), fecha_gestion, 120) as fecha_gestion,
                    {tipo_col}, {prod_col}, {tipo_clas_col}, {resultado_clas_col}, {tel_cont_col}
                FROM {T_GESTIONES}
                WHERE cu = ?
                ORDER BY fecha_gestion DESC
            """
            
            cur.execute(sql, (cu,))
            rows = cur.fetchall()
            
            data = []
            for r in rows:
                data.append({
                    "usuario": r[0],
                    "nombre": r[1],
                    "cu": r[2],
                    "cj": r[3],
                    "capital": r[4],
                    "deuda_total": r[5],
                    "telefono": r[6],
                    "fecha": r[7],
                    "tipo_gestion": r[8],
                    "grupo_producto": r[9],
                    "tipo_clasificacion": r[10],
                    "resultado_clasificacion": r[11],
                    "telefono_contacto": r[12] # Nuevo campo
                })
                
        return jsonify({"ok": True, "data": data})
    except Exception as e:
        return jsonify({"ok": False, "msg": f"Error al consultar gestiones: {e}"}), 500
    
@app.route("/api/export-gestiones", methods=["GET"])
@role_required(1) 
def api_export_gestiones():
    fecha_inicio = request.args.get("inicio")
    fecha_fin = request.args.get("fin")
    if not fecha_inicio or not fecha_fin:
        return "Fechas requeridas", 400
    sql = f"""
        SELECT * FROM {T_GESTIONES} 
        WHERE CAST(fecha_gestion AS DATE) BETWEEN ? AND ?
        ORDER BY fecha_gestion DESC
    """
    
    try:
        with db_conn() as conn:
            df = pd.read_sql(sql, conn, params=[fecha_inicio, fecha_fin])
            
        if df.empty:
            return "No se encontraron registros en el rango seleccionado", 404
        output = BytesIO()
        try:
            with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
                df.to_excel(writer, index=False, sheet_name='Gestiones')
        except ImportError:
            output = BytesIO()
            with pd.ExcelWriter(output, engine='openpyxl') as writer:
                df.to_excel(writer, index=False, sheet_name='Gestiones')
        
        output.seek(0)
        return Response(
            output,
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment;filename=Reporte_Gestiones_{fecha_inicio}_a_{fecha_fin}.xlsx"}
        )
    except Exception as e:
        return str(e), 500
@app.route("/health")
def health():
    return jsonify({"status": "ok", "time": time.time()})
# ─────────────────────────────────────────
# ARRANQUE DE PRUEBAS (WAITRESS) — PUERTO 5050 PARA NO CHOCAR CON PRODUCCIÓN
# ─────────────────────────────────────────
if __name__ == "__main__":
    from waitress import serve
    import logging
    # Opcional: Configuramos logging para monitorear el acceso al servidor en consola
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')
    logger = logging.getLogger('waitress')
    logger.setLevel(logging.INFO)
    print("Iniciando servidor de PRUEBAS usando Waitress...")
    print("http://0.0.0.0:5050")
    
    # Puerto cambiado a 5050 solo para el ambiente de pruebas.
    serve(app, host="0.0.0.0", port=5050, threads=6)
