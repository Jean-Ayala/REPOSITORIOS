from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from app.auth import login_required, role_required, me, ip
from app.database import (crear_solicitud, editar_solicitud, cambiar_estado_solicitud,
                           get_solicitud, get_historial_solicitud, get_solicitudes_gestor,
                           buscar_en_padron_por_cj, get_periodos_por_cj,
                           get_montos_por_cj_periodo, log)
from app.utils import allowed_pdf, save_file, mes_actual, fmt_mes
from app.config import Config

ges_bp = Blueprint('ges', __name__)
ESTADOS = ['Borrador','Enviado','Aprobado','Rechazado','Observado']


def to_float(val):
    try:
        return float(str(val).replace(',','').replace('S/','').strip() or 0)
    except:
        return 0.0


def clasificar_nivel(monto, imp_min, imp_opt, imp_max):
    if imp_max > 0 and monto >= imp_max:
        return 'MAXIMO'
    elif imp_opt > 0 and monto >= imp_opt:
        return 'OPTIMO'
    elif imp_min > 0 and monto >= imp_min:
        return 'MINIMO'
    else:
        return 'ALERTA'


@ges_bp.route('/dashboard')
@role_required('gestor')
def dashboard():
    u = me()
    solicitudes, total = get_solicitudes_gestor(u['id'], page=1, per_page=8)
    return render_template('ges_dashboard.html', user=u,
                           solicitudes=solicitudes, total=total,
                           mes=mes_actual(), fmt_mes=fmt_mes)


@ges_bp.route('/nueva', methods=['GET','POST'])
@role_required('gestor')
def nueva():
    u = me()
    if request.method == 'POST':
        action = request.form.get('action','borrador')
        cj     = request.form.get('cj','').strip()

        if not cj:
            flash('El CJ es obligatorio.','danger')
            return redirect(url_for('ges.nueva'))

        monto   = to_float(request.form.get('monto_ingresado', 0))
        capital = to_float(request.form.get('capital_referencia', 0))
        imp_min = to_float(request.form.get('imp_minimo', 0))
        imp_opt = to_float(request.form.get('imp_optimo', 0))
        imp_max = to_float(request.form.get('imp_maximo', 0))

        nivel = clasificar_nivel(monto, imp_min, imp_opt, imp_max)

        # PDF obligatorio si monto < capital
        archivo_pdf_nombre, archivo_pdf_ruta = '', ''
        pdf = request.files.get('archivo_pdf')
        if pdf and pdf.filename and allowed_pdf(pdf.filename):
            archivo_pdf_nombre, archivo_pdf_ruta = save_file(pdf, 'pdfs')
        elif capital > 0 and monto < capital:
            flash('El monto es menor al capital. Debes adjuntar la nota de abono (PDF).','danger')
            return redirect(url_for('ges.nueva'))

        d = {
            'cu':                request.form.get('cu','').strip(),
            'cj':                cj,
            'nombre_cliente':    request.form.get('nombre_cliente','').strip() or 'Sin nombre',
            'producto':          request.form.get('producto',''),
            'saldo_total':       capital,
            'dias_mora':         None,
            'campana_id':        1,
            'monto_minimo_camp': imp_max,
            'pago_realizado':    monto,
            'monto_a_condonar':  0,
            'gestor_id':         u['id'],
            'estado':            'Enviado' if action=='enviar' else 'Borrador',
            'observacion_gestor':request.form.get('observacion_gestor',''),
            'mes_referencia':    mes_actual(),
            'importe_ingresado': monto,
            'nivel_pago':        nivel,
            'capital_referencia':capital,
            'fecha_castigo':     request.form.get('fecha_castigo','') or None,
            'archivo_pdf_nombre':archivo_pdf_nombre,
            'archivo_pdf_ruta':  archivo_pdf_ruta,
            'periodo_campana':   request.form.get('periodo',''),
        }
        sid = crear_solicitud(d)
        log(u['id'],'SOLICITUD_CREADA',
            f"SID={sid}|CJ={cj}|Nivel={nivel}|Monto={monto}",
            tabla='cob_tr_solicitudes_recovery', id_ref=sid, ip=ip())
        flash(f'Solicitud #{sid} {"enviada" if d["estado"]=="Enviado" else "guardada como borrador"}.','success')
        return redirect(url_for('ges.mis_solicitudes'))

    return render_template('ges_form.html', user=u, mes=mes_actual(), solicitud=None, modo='nueva')


@ges_bp.route('/mis-solicitudes')
@role_required('gestor')
def mis_solicitudes():
    u      = me()
    page   = int(request.args.get('page',1))
    estado = request.args.get('estado','')
    solicitudes, total = get_solicitudes_gestor(u['id'], page=page, estado=estado or None)
    pages = (total + Config.ROWS_PER_PAGE - 1) // Config.ROWS_PER_PAGE
    return render_template('ges_lista.html', user=u,
                           solicitudes=solicitudes, total=total,
                           page=page, pages=pages, estado=estado, ESTADOS=ESTADOS)


@ges_bp.route('/ver/<int:sid>')
@role_required('gestor')
def ver(sid):
    u = me()
    s = get_solicitud(sid)
    if not s or s['gestor_id'] != u['id']:
        flash('Sin acceso.','danger')
        return redirect(url_for('ges.mis_solicitudes'))
    h = get_historial_solicitud(sid)
    return render_template('detalle.html', user=u, s=s, historial=h)


@ges_bp.route('/api/buscar-cj')
@role_required('gestor')
def api_buscar_cj():
    cj  = request.args.get('cj','').strip()
    mes = mes_actual()
    if not cj: return jsonify({'found':False})
    dato = buscar_en_padron_por_cj(cj, mes)
    if dato:
        periodos = get_periodos_por_cj(cj)
        return jsonify({'found':True,
                        'cu':            dato['cu'],
                        'nombre_cliente':dato['nombre_cliente'],
                        'producto':      dato['producto'],
                        'capital':       dato['capital'],
                        'fecha_castigo': dato['fecha_castigo'],
                        'periodos':      periodos})
    return jsonify({'found':False})


@ges_bp.route('/api/montos-periodo')
@role_required('gestor')
def api_montos_periodo():
    cj      = request.args.get('cj','').strip()
    periodo = request.args.get('periodo','').strip()
    if not cj or not periodo: return jsonify({'found':False})
    montos = get_montos_por_cj_periodo(cj, periodo)
    if montos:
        return jsonify({'found':True, **montos})
    return jsonify({'found':False})
