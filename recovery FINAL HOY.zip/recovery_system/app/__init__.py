import os
from flask import Flask, session, redirect, url_for, request, flash, render_template, Blueprint
from app.config import Config
from app.database import auth_usuario, log
from app.auth import ip

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    app.config['MAX_CONTENT_LENGTH'] = Config.MAX_CONTENT_MB * 1024 * 1024
    os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)

    # Filtro de formato de moneda con coma
    @app.template_filter('moneda')
    def moneda_filter(valor):
        if valor is None: return '—'
        try: return f"S/ {float(valor):,.2f}"
        except: return '—'

    @app.template_filter('num')
    def num_filter(valor):
        if valor is None: return '—'
        try: return f"{float(valor):,.2f}"
        except: return '—'


    # ── AUTH BLUEPRINT ────────────────────────────────────────
    auth_bp = Blueprint('auth', __name__)

    @auth_bp.route('/', methods=['GET','POST'])
    @auth_bp.route('/login', methods=['GET','POST'])
    def login():
        if 'uid' in session:
            return redirect(url_for('sup.dashboard') if session['rol']=='supervisor'
                            else url_for('ges.dashboard'))
        error = None
        if request.method == 'POST':
            u = request.form.get('username','').strip().upper()
            p = request.form.get('password','').strip()
            user = auth_usuario(u, p)
            if user:
                session.update(uid=user['id'], username=user['username'],
                               rol=user['rol'], nombre=user['nombre'])
                log(user['id'],'LOGIN',ip=ip())
                return redirect(url_for('sup.dashboard') if user['rol']=='supervisor'
                                else url_for('ges.dashboard'))
            error = 'Usuario o contraseña incorrectos.'
        return render_template('login.html', error=error)

    @auth_bp.route('/logout')
    def logout():
        if uid := session.get('uid'):
            log(uid,'LOGOUT',ip=ip())
        session.clear()
        return redirect(url_for('auth.login'))

    app.register_blueprint(auth_bp)

    # ── GESTOR BLUEPRINT ──────────────────────────────────────
    from app.routes_gestor import ges_bp
    app.register_blueprint(ges_bp, url_prefix='/gestor')

    # ── SUPERVISOR BLUEPRINT ──────────────────────────────────
    from app.routes_supervisor import sup_bp
    app.register_blueprint(sup_bp, url_prefix='/supervisor')

    # ── ERROR HANDLERS ────────────────────────────────────────
    @app.errorhandler(413)
    def too_large(e):
        flash(f'Archivo muy grande. Máximo {Config.MAX_CONTENT_MB} MB.','danger')
        return redirect(request.referrer or url_for('auth.login'))

    @app.errorhandler(404)
    def not_found(e):
        return render_template('login.html', error='Página no encontrada.'), 404

    return app
