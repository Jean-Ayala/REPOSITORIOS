import os, uuid
from flask import (Blueprint, render_template, request, redirect,
                   url_for, flash, send_file, jsonify)
from app.auth import role_required, login_required, me, ip
from app.database import (get_solicitudes_supervisor, get_kpis_supervisor, get_top_gestores, get_stats_niveles_pago,
                           get_solicitud, get_historial_solicitud,
                           cambiar_estado_solicitud,
                           get_todos_gestores, get_todas_campanas,
                           get_campanas_activas, crear_campana, toggle_campana,
                           get_monto_por_campana,
                           padron_tiene_carga, borrar_padron_mes,
                           insertar_padron_batch_v2, stats_padron,
                           reg_carga_padron, upd_carga_padron, get_cargas_padron,
                           get_bitacora_extendida,
                           get_resumen_por_gestor, log, get_conn)
from app.utils import (allowed, save_file, leer_excel_padron,
                        exportar_excel, mes_actual, fmt_mes)
from app.config import Config

sup_bp = Blueprint('sup', __name__)
ESTADOS = ['Borrador','Enviado','Aprobado','Rechazado','Observado']


@sup_bp.route('/dashboard')
@role_required('supervisor')
def dashboard():
    u   = me()
    mes = request.args.get('mes', mes_actual())
    kpi = get_kpis_supervisor(mes)
    stp = stats_padron(mes)
    cmp = get_monto_por_campana()
    top = get_top_gestores(3)
    top_todos = get_top_gestores(99)
    niveles = get_stats_niveles_pago(mes)
    return render_template('sup_dashboard.html', user=u,
                           mes=mes, fmt_mes=fmt_mes, kpi=kpi,
                           stats_padron=stp, campana_stats=cmp,
                           top_gestores=top,
                           top_gestores_todos=top_todos,
                           niveles=niveles)

@sup_bp.route('/solicitudes')
@role_required('supervisor')
def solicitudes():
    u = me()
    mes = request.args.get('mes', mes_actual())
    if len(mes) == 6:
        mes = mes[:4] + '-' + mes[4:]
    filtros = {
        'gestor_id':   request.args.get('gestor_id') or None,
        'estado':      request.args.get('estado',''),
        'campana_id':  request.args.get('campana_id') or None,
        'solo_alertas':request.args.get('alertas')=='1',
        'q':           request.args.get('q','').strip(),
        'mes':         mes,
    }
    page = int(request.args.get('page',1))
    lista, total = get_solicitudes_supervisor(filtros, page=page)
    pages    = (total + Config.ROWS_PER_PAGE-1) // Config.ROWS_PER_PAGE
    gestores = get_todos_gestores()
    campanas = get_todas_campanas()
    kpi      = get_kpis_supervisor(mes)
    return render_template('sup_solicitudes.html', user=u,
                           lista=lista, total=total, page=page, pages=pages,
                           gestores=gestores, campanas=campanas,
                           filtros=filtros, kpi=kpi,
                           mes=mes, fmt_mes=fmt_mes, ESTADOS=ESTADOS)


@sup_bp.route('/ver/<int:sid>')
@role_required('supervisor')
def ver(sid):
    u = me()
    s = get_solicitud(sid)
    if not s: flash('No encontrada.','danger'); return redirect(url_for('sup.solicitudes'))
    h = get_historial_solicitud(sid)
    return render_template('detalle.html', user=u, s=s, historial=h)


@sup_bp.route('/resolver/<int:sid>', methods=['POST'])
@role_required('supervisor')
def resolver(sid):
    u     = me()
    accion= request.form.get('accion','')
    comt  = request.form.get('comentario','').strip()
    mapa  = {'aprobar':'Aprobado','rechazar':'Rechazado','observar':'Observado'}
    nuevo = mapa.get(accion)
    if not nuevo:
        flash('Acción no válida.','danger'); return redirect(url_for('sup.ver',sid=sid))
    ok = cambiar_estado_solicitud(sid, nuevo, u['id'], comt)
    if ok:
        log(u['id'],f'SOL_{nuevo.upper()}',f"SID={sid}|{comt}",
            tabla='solicitudes',id_ref=sid,ip=ip())
        flash(f'Solicitud #{sid} → {nuevo}.','success')
    return redirect(url_for('sup.ver', sid=sid))


@sup_bp.route('/exportar')
@role_required('supervisor')
def exportar():
    u   = me()
    mes = request.args.get('mes', mes_actual())
    filtros = {
        'gestor_id':   request.args.get('gestor_id') or None,
        'estado':      request.args.get('estado',''),
        'solo_alertas':request.args.get('alertas')=='1',
        'q':           request.args.get('q','').strip(),
        'mes':         mes,
    }
    lista, _ = get_solicitudes_supervisor(filtros, page=1, per_page=99999)
    ruta, nombre = exportar_excel(lista)
    log(u['id'],'EXPORTAR',f"Mes={mes}|Filas={len(lista)}",ip=ip())
    return send_file(ruta, as_attachment=True, download_name=nombre)


@sup_bp.route('/exportar-bitacora')
@role_required('supervisor')
def exportar_bitacora():
    u = me()
    lista, _ = get_bitacora_extendida(page=1, per_page=99999)
    ruta, nombre = exportar_excel(lista)
    log(u['id'],'EXPORTAR_BITACORA',ip=ip())
    return send_file(ruta, as_attachment=True, download_name=nombre)


@sup_bp.route('/campanas', methods=['GET','POST'])
@role_required('supervisor')
def campanas():
    u = me()
    if request.method=='POST':
        try:
            d = {
                'nombre':       request.form.get('nombre','').strip(),
                'descripcion':  request.form.get('descripcion','').strip(),
                'monto_minimo': float(request.form.get('monto_minimo',0) or 0),
                'fecha_inicio': request.form.get('fecha_inicio'),
                'fecha_fin':    request.form.get('fecha_fin'),
            }
            if not d['nombre']:
                flash('El nombre es obligatorio.','danger')
            else:
                cid = crear_campana(d, u['id'])
                log(u['id'],'CAMPANA_CREADA',f"CID={cid}|{d['nombre']}",ip=ip())
                flash(f'Campaña "{d["nombre"]}" creada.','success')
        except ValueError:
            flash('Monto mínimo debe ser número.','danger')
        return redirect(url_for('sup.campanas'))
    lista = get_todas_campanas()
    return render_template('sup_campanas.html', user=u, campanas=lista)


@sup_bp.route('/campanas/toggle/<int:cid>', methods=['POST'])
@role_required('supervisor')
def toggle_camp(cid):
    toggle_campana(cid, request.form.get('activa')=='1')
    flash('Estado de campaña actualizado.','success')
    return redirect(url_for('sup.campanas'))


@sup_bp.route('/padron', methods=['GET','POST'])
@role_required('supervisor')
def padron():
    u = me()
    if request.method=='POST':
        mes        = request.form.get('mes', mes_actual()).strip()
        file       = request.files.get('archivo')
        reemplazar = request.form.get('reemplazar')=='1'

        if not file or not file.filename:
            flash('Selecciona un archivo.','danger')
            return redirect(url_for('sup.padron'))
        if not allowed(file.filename):
            flash('Solo .xlsx, .xls o .csv','danger')
            return redirect(url_for('sup.padron'))
        if padron_tiene_carga(mes) and not reemplazar:
            flash(f'Ya hay carga para {fmt_mes(mes)}. Marca "Reemplazar".','warning')
            return redirect(url_for('sup.padron'))

        orig_name, ruta = save_file(file, 'cargas')
        cid = reg_carga_padron(u['id'], file.filename, ruta, mes)
        log(u['id'],'PADRON_CARGA_INICIO',f"Archivo={file.filename}|Mes={mes}",ip=ip())

        filas, total, errores, msg_err = leer_excel_padron(ruta)
        if msg_err:
            upd_carga_padron(cid,0,0,0,'error',msg_err)
            flash(f'Error al procesar: {msg_err}','danger')
            return redirect(url_for('sup.padron'))

        try:
            lote_id = str(uuid.uuid4())
            conn    = get_conn()
            if reemplazar:
                borrar_padron_mes(mes, conn)
            insertar_padron_batch_v2(filas, mes, u['id'], lote_id, conn)
            conn.commit(); conn.close()
            upd_carga_padron(cid, total+errores, total, errores, 'completado')
            log(u['id'],'PADRON_CARGA_OK',f"Mes={mes}|OK={total}|Err={errores}",ip=ip())
            flash(f'Padrón cargado: {total:,} cuentas'
                  +(f' ({errores:,} filas con error omitidas)' if errores else '')+'.','success')
        except Exception as e:
            upd_carga_padron(cid,0,0,0,'error',str(e))
            flash(f'Error al guardar: {e}','danger')
        return redirect(url_for('sup.padron'))

    historial = get_cargas_padron()
    return render_template('sup_padron.html', user=u,
                           historial=historial, mes_actual=mes_actual(), fmt_mes=fmt_mes)


@sup_bp.route('/bitacora')
@role_required('supervisor')
def bitacora():
    u          = me()
    page       = int(request.args.get('page',1))
    uid_f      = request.args.get('uid') or None
    accion_f   = request.args.get('accion','').strip()
    fecha_desde= request.args.get('fecha_desde','')
    fecha_hasta= request.args.get('fecha_hasta','')

    lista, total = get_bitacora_extendida(
        page=page, per_page=100,
        uid_filter=uid_f,
        accion_filter=accion_f or None,
        fecha_desde=fecha_desde or None,
        fecha_hasta=fecha_hasta or None
    )
    pages            = (total+99)//100
    gestores         = get_todos_gestores()
    resumen_gestores = get_resumen_por_gestor()

    return render_template('sup_bitacora.html', user=u,
                           lista=lista, total=total, page=page, pages=pages,
                           gestores=gestores,
                           resumen_gestores=resumen_gestores,
                           uid_f=uid_f, accion_f=accion_f,
                           fecha_desde=fecha_desde, fecha_hasta=fecha_hasta)


@sup_bp.route('/api/kpis')
@role_required('supervisor')
def api_kpis():
    mes = request.args.get('mes', mes_actual())
    return jsonify({'kpi': get_kpis_supervisor(mes),
                    'padron': stats_padron(mes)})


@sup_bp.route('/semaforo')
@role_required('supervisor')
def semaforo():
    u   = me()
    mes = request.args.get('mes', mes_actual())
    gestores = get_top_gestores(99)
    return render_template('sup_semaforo.html', user=u,
                           mes=mes, fmt_mes=fmt_mes, gestores=gestores)


@sup_bp.route('/ver-pdf/<int:sid>')
@role_required('supervisor')
def ver_pdf(sid):
    import os
    s = get_solicitud(sid)
    if not s:
        flash('Solicitud no encontrada.','danger')
        return redirect(url_for('sup.solicitudes'))
    ruta = s.get('archivo_pdf_ruta','')
    if not ruta or not os.path.exists(ruta):
        flash('No hay PDF adjunto para esta solicitud.','warning')
        return redirect(url_for('sup.ver', sid=sid))
    nombre = s.get('archivo_pdf_nombre','nota_abono.pdf')
    return send_file(ruta, as_attachment=True, download_name=f'nota_abono_{sid}.pdf')
