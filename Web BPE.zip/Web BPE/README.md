# Alertas de Teléfonos - BPE

Web mínima (Flask) para subir la asignación del día y detectar problemas
de priorización/contacto. La lógica está calcada 1:1 de
`query_priorizacion_simplificada.sql` (la que ya validaste en SSMS) --
si algún resultado se ve raro, compara primero contra esa query, es la
fuente de verdad.

## Qué calcula, por cliente

- **cliente_nuevo_sin_historico**: `SI` si `meses_con_gestion == 1`
  (es su primer mes asignado; el resto de columnas se apagan porque no
  hay base histórica todavía para juzgarlo).
- **mes_ultimo_ce / telefono_ultimo_ce**: el mes MÁS RECIENTE en que tuvo
  contacto efectivo, y el teléfono con el que se logró.
- **A1_score_mal_priorizado**: `NO` o `SI - pos X` -- el teléfono del
  ce más reciente existe en la asignación, pero no está en `telefono1`.
- **A2_telefono_no_asignado**: `SI`/`NO` -- el teléfono del ce más
  reciente ni siquiera está en la asignación de hoy.
- **sin_ce_ultimos_3_meses**: `SI`/`NO` -- no tuvo ningún ce en los 3
  meses cerrados más recientes (no cuenta el mes en curso, que aún
  está incompleto).
- **sin_ce_todo_2026**: `SI`/`NO` -- nunca tuvo un ce en todo el
  histórico consultado (desde enero).
- **necesita_revision**: resumen `SI`/`NO` de todo lo anterior.

## Instalación

```bash
cd web_alertas_bpe
python -m venv venv
venv\Scripts\activate        # en Windows
pip install -r requirements.txt
```

Revisa en `app.py` las constantes al inicio (servidor/base de datos).
Si tu conexión no es con usuario de Windows, cambia `get_conn()`.

## Correr

```bash
python app.py
```

Abre `http://localhost:5000`.

## Uso

1. Sube el Excel de asignación del día (`codunicocli`, `telefono1..10`).
2. La app trae de SQL Server el histórico de ce y los meses de gestión
   de esos clientes (usa tablas temporales + JOIN con CAST/TRIM para
   evitar problemas de tipo de dato).
3. Verás los KPIs (A1, A2, sin ce 3 meses, sin ce todo 2026, nuevos) y
   la tabla detalle, ordenada primero por los que necesitan revisión.
4. **Exportar a Excel**: descarga el detalle completo.
5. **Descargar imagen del dashboard**: `.png` de las tarjetas de KPI
   para mandar por donde quieras (no envía nada automáticamente).

## Auto-chequeo de datos

Si 0 clientes traen algún ce histórico, o más del 30% sale como
"cliente nuevo", la web te muestra una advertencia en rojo antes de
que exportes/uses el resultado -- es señal de que la consulta no trajo
los datos bien, no de que la mayoría sean casos nuevos de verdad. En
ese caso, corre `diagnostico_cliente_puntual.sql` con 2-3 códigos que
conozcas para confirmar.

## Notas

- Está escrita asumiendo que "los últimos 3 meses cerrados" se calculan
  dinámicamente contra la fecha real del servidor (no hardcodeado a
  agosto), así que no necesitas tocar nada al cambiar de mes.
- El resultado se guarda en memoria del proceso Flask; si la usan
  varias personas a la vez, conviene guardar cada resultado con un id
  de sesión o en disco.
