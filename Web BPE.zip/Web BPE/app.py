"""
Web de Alertas de Teléfonos - BPE
----------------------------------
Esta versión implementa EXACTAMENTE la misma lógica que ya validaste en
SSMS con query_priorizacion_simplificada.sql. Si algún resultado no
calza, lo primero es comparar contra esa query (que es la fuente de
verdad) antes de asumir que el bug está en la web.

Flujo:
  1. Subes el Excel de asignación del día (codunicocli, telefono1..10).
  2. La app trae de SQL Server:
       a) el histórico de contacto efectivo (ce) de esos clientes
       b) cuántos meses lleva cada uno asignado (meses_con_gestion)
  3. Por cliente:
       - si meses_con_gestion == 1           -> CLIENTE_NUEVO_SIN_HISTORICO
       - si no, se busca el MES MÁS RECIENTE con ce y su teléfono:
           - si ese teléfono no es telefono1  -> A1_SCORE_MAL_PRIORIZADO
           - si ni siquiera está asignado     -> A2_TELEFONO_NO_ASIGNADO
       - si no tuvo ce en los últimos 3 meses cerrados -> SIN_CE_ULTIMOS_3_MESES
       - si nunca tuvo ce en todo el histórico          -> SIN_CE_TODO_2026
  4. Dashboard con KPIs + tabla detalle + exportar a Excel.

Cómo correr:
    pip install -r requirements.txt
    python app.py
    abrir http://localhost:5000
"""

import io
from datetime import datetime

import pandas as pd
import pyodbc
from flask import Flask, render_template, request, send_file

app = Flask(__name__)
app.secret_key = "cambia-esto-por-algo-seguro"

# ---------------------------------------------------------------------------
# CONFIGURACIÓN - ajusta si tu driver/instancia es distinto
# ---------------------------------------------------------------------------
DB_SERVER = r"s528vp04\bdt"
DB_NAME = "gic"
CAMPANAS = ("cob_bpe_00", "cob_bpe_01", "cob_bpe_02")
MES_DESDE = "202601"  # arranque del histórico (igual que en la query SQL)

ULTIMO_RESULTADO = {"df": None, "generado": None, "resumen": None}


# ---------------------------------------------------------------------------
# Utilidades
# ---------------------------------------------------------------------------
def get_conn():
    conn_str = (
        "DRIVER={ODBC Driver 17 for SQL Server};"
        f"SERVER={DB_SERVER};DATABASE={DB_NAME};Trusted_Connection=yes;"
    )
    return pyodbc.connect(conn_str)


def limpiar_numero(valor):
    """Normaliza códigos de cliente y teléfonos que vienen del Excel.
    Pandas suele leer estas columnas como float (ej. 990356503.0); si
    solo hacemos str(valor) queda "990356503.0" y nunca calza contra el
    valor limpio que viene de SQL. Deja solo dígitos, sin decimales ni
    espacios. Devuelve None si no queda ningún dígito válido (o es cero).
    """
    if pd.isna(valor):
        return None
    texto = str(valor).strip()
    if texto.endswith(".0"):
        texto = texto[:-2]
    texto = "".join(ch for ch in texto if ch.isdigit())
    if texto == "" or texto == "0":
        return None
    return texto


def _periodo_a_num_meses(periodo):
    """'YYYYMM' (ej. '202608') -> entero absoluto de meses (año*12+mes)."""
    periodo = str(periodo)
    return int(periodo[:4]) * 12 + int(periodo[4:6])


def _num_meses_a_periodo(num):
    """Inverso de _periodo_a_num_meses: entero absoluto -> 'YYYYMM'."""
    year = (num - 1) // 12
    month = (num - 1) % 12 + 1
    return f"{year:04d}{month:02d}"


def meses_cerrados_recientes(periodo_actual, cantidad=3):
    """Los N meses CERRADOS más recientes, sin incluir el mes en curso.
    Para periodo_actual='202608' (agosto) y cantidad=3 devuelve
    ['202605','202606','202607'] (mayo, junio, julio) -- igual que en
    la query SQL validada."""
    num_actual = _periodo_a_num_meses(periodo_actual)
    return [_num_meses_a_periodo(num_actual - d) for d in range(cantidad, 0, -1)]


# ---------------------------------------------------------------------------
# Lectura del Excel subido
# ---------------------------------------------------------------------------
def leer_asignacion(file_storage):
    """Lee el Excel subido y devuelve un DataFrame:
    codunicocli, posicion (1-10), telefono (solo filas con teléfono válido).
    """
    df = pd.read_excel(file_storage)
    df.columns = [c.strip().lower() for c in df.columns]

    if "codunicocli" not in df.columns:
        raise ValueError("El Excel debe tener una columna 'codunicocli'.")

    cols_tlf = [f"telefono{i}" for i in range(1, 11) if f"telefono{i}" in df.columns]
    if not cols_tlf:
        raise ValueError("No encontré columnas telefono1..telefono10 en el Excel.")

    filas = []
    for _, row in df.iterrows():
        cu = limpiar_numero(row["codunicocli"])
        if cu is None:
            continue
        for i, col in enumerate(cols_tlf, start=1):
            tel = limpiar_numero(row[col])
            if tel is None:
                continue
            filas.append({"codunicocli": cu, "posicion": i, "telefono": tel})

    return pd.DataFrame(filas)


# ---------------------------------------------------------------------------
# Consultas a SQL Server
# ---------------------------------------------------------------------------
def obtener_historico_ce(codunicoclis):
    """Trae de SQL Server el histórico de contacto efectivo (ce) SOLO
    para los clientes de la lista: 1 fila por (codunicocli, mes) con el
    teléfono que generó ese ce. Usa una tabla temporal + JOIN con
    CAST/TRIM explícito (no un simple IN) para evitar problemas de tipo
    de dato entre el codunicocli del Excel y el [contact id] de SQL."""
    if not codunicoclis:
        return pd.DataFrame(columns=["codunicocli", "mes", "telefono"])

    codunicoclis = list({c for c in (limpiar_numero(x) for x in codunicoclis) if c is not None})

    conn = get_conn()
    cursor = conn.cursor()
    cursor.fast_executemany = True

    cursor.execute("CREATE TABLE #clientes_hoy (codunicocli VARCHAR(50))")
    cursor.executemany(
        "INSERT INTO #clientes_hoy (codunicocli) VALUES (?)",
        [(c,) for c in codunicoclis],
    )
    conn.commit()

    query = f"""
        with tipis as (
            select
                periodo as mes,
                ch.codunicocli,
                [wrap-up],
                right(dnis,9) as telefono,
                orden = row_number() over (partition by ch.codunicocli, periodo order by fecha_key asc)
            from ykr_tb_cob_intentos as a
            inner join #clientes_hoy ch
                on try_cast(ltrim(rtrim(a.[contact id])) as bigint) = try_cast(ch.codunicocli as bigint)
            left join (
                select conlusion_cloud as conclusion, 1 as resultado
                from ob_conclusiones_cloud_5
                where tipo_resultado in ('pdp','pdp - fdp','contacto - efectivo')
            ) as b on b.conclusion = a.[wrap-up]
            where (b.resultado = 1
                   or lower(ltrim(rtrim(a.[wrap-up]))) in ('pdp','pdp - fdp','contacto - efectivo'))
              and [campaign name] in {CAMPANAS}

            union all

            select
                periodo as mes,
                ch.codunicocli,
                [wrap-up],
                right(dnis,9) as telefono,
                orden = row_number() over (partition by ch.codunicocli, periodo order by fecha_key asc)
            from ykr_tb_cob_intentos_bkp as a
            inner join #clientes_hoy ch
                on try_cast(ltrim(rtrim(a.[contact id])) as bigint) = try_cast(ch.codunicocli as bigint)
            left join (
                select conlusion_cloud as conclusion, 1 as resultado
                from ob_conclusiones_cloud_5
                where tipo_resultado in ('pdp','pdp - fdp','contacto - efectivo')
            ) as b on b.conclusion = a.[wrap-up]
            where (b.resultado = 1
                   or lower(ltrim(rtrim(a.[wrap-up]))) in ('pdp','pdp - fdp','contacto - efectivo'))
              and [campaign name] in {CAMPANAS}
              and cast(periodo as int) >= {MES_DESDE}
        )
        select codunicocli, mes, telefono
        from tipis
        where orden = 1;
    """
    hist = pd.read_sql(query, conn)
    conn.close()

    hist.columns = [c.lower() for c in hist.columns]
    hist["codunicocli"] = hist["codunicocli"].apply(limpiar_numero)
    hist["telefono"] = hist["telefono"].apply(limpiar_numero)
    hist = hist.dropna(subset=["codunicocli", "telefono"])
    return hist


def obtener_meses_con_gestion(codunicoclis, periodo_actual):
    """Cuenta, para cada cliente, en cuántos meses distintos (desde
    MES_DESDE hasta el mes actual) apareció asignado en tramo
    temprana/intermedia/tardia -- exactamente lo mismo que la columna
    'meses_con_gestion' de tu query original. meses_con_gestion == 1
    significa que es su primer mes: cliente nuevo, sin base histórica.
    """
    if not codunicoclis:
        return pd.DataFrame(columns=["codunicocli", "meses_con_gestion"])

    codunicoclis = list({c for c in (limpiar_numero(x) for x in codunicoclis) if c is not None})

    conn = get_conn()
    cursor = conn.cursor()
    cursor.fast_executemany = True

    cursor.execute("CREATE TABLE #clientes_asig (codunicocli VARCHAR(50))")
    cursor.executemany(
        "INSERT INTO #clientes_asig (codunicocli) VALUES (?)",
        [(c,) for c in codunicoclis],
    )
    conn.commit()

    query = f"""
        select
            ch.codunicocli,
            count(distinct a.codmes) as meses_con_gestion
        from cob_trf_bpe_asignacion_historico a
        inner join #clientes_asig ch
            on try_cast(ltrim(rtrim(a.codunicocli)) as bigint) = try_cast(ch.codunicocli as bigint)
        where a.codmes between '{MES_DESDE}' and '{periodo_actual}'
          and a.tramo_asignacion in ('temprana','intermedia','tardia')
        group by ch.codunicocli;
    """
    df = pd.read_sql(query, conn)
    conn.close()

    df.columns = [c.lower() for c in df.columns]
    df["codunicocli"] = df["codunicocli"].apply(limpiar_numero)
    df = df.dropna(subset=["codunicocli"])
    return df


# ---------------------------------------------------------------------------
# Lógica de negocio (debe calzar 1:1 con query_priorizacion_simplificada.sql)
# ---------------------------------------------------------------------------
def evaluar_clientes(asignacion_df, historico_df, meses_gestion_df, periodo_actual):
    """Devuelve 1 fila por cliente con TODAS las columnas de alerta,
    replicando la lógica ya validada en SQL:

        cliente_nuevo_sin_historico : meses_con_gestion == 1
        mes_ultimo_ce / telefono_ultimo_ce
        A1_score_mal_priorizado     : 'NO' o 'SI - pos X'
        A2_telefono_no_asignado     : 'SI'/'NO'
        sin_ce_ultimos_3_meses      : 'SI'/'NO'
        sin_ce_todo_2026            : 'SI'/'NO'
        necesita_revision           : 'SI'/'NO'
    """
    meses_gestion_map = dict(zip(meses_gestion_df["codunicocli"], meses_gestion_df["meses_con_gestion"]))
    clientes_todos = list(asignacion_df["codunicocli"].unique())

    # --- teléfono asignado -> posición, con MIN() por si el mismo
    #     teléfono aparece duplicado en más de una posición ---
    telefonos_asignados = (
        asignacion_df.groupby(["codunicocli", "telefono"], as_index=False)["posicion"].min()
    )
    mapa_posicion = {
        (r.codunicocli, r.telefono): r.posicion for r in telefonos_asignados.itertuples()
    }

    # --- mes/telefono más reciente con ce, por cliente ---
    telefono_ultimo_ce = {}
    mes_ultimo_ce = {}
    if len(historico_df):
        h = historico_df.copy()
        h["mes_num"] = h["mes"].apply(_periodo_a_num_meses)
        idx_reciente = h.groupby("codunicocli")["mes_num"].idxmax()
        for r in h.loc[idx_reciente].itertuples():
            telefono_ultimo_ce[r.codunicocli] = r.telefono
            mes_ultimo_ce[r.codunicocli] = r.mes

    # --- meses ce por cliente (para el check "sin_ce_todo_2026" y
    #     "sin_ce_ultimos_3_meses") ---
    meses_ce_por_cliente = {}
    if len(historico_df):
        for cu, grupo in historico_df.groupby("codunicocli"):
            meses_ce_por_cliente[cu] = set(grupo["mes"])

    meses_recientes = set(meses_cerrados_recientes(periodo_actual, cantidad=3))

    filas = []
    for cu in clientes_todos:
        meses_gestion = meses_gestion_map.get(cu, 0)
        nuevo = meses_gestion == 1

        tlf_reciente = telefono_ultimo_ce.get(cu)
        mes_reciente = mes_ultimo_ce.get(cu)
        posicion = mapa_posicion.get((cu, tlf_reciente)) if tlf_reciente else None

        if nuevo:
            a1 = "NO"
            a2 = "NO"
        elif tlf_reciente is None:
            a1 = "NO"
            a2 = "NO"
        elif posicion == 1:
            a1 = "NO"
            a2 = "NO"
        elif posicion is not None:
            a1 = f"SI - pos {posicion}"
            a2 = "NO"
        else:
            a1 = "NO"
            a2 = "SI"

        meses_ce_cliente = meses_ce_por_cliente.get(cu, set())
        if nuevo:
            sin_ce_3m = "NO"
            sin_ce_2026 = "NO"
        else:
            sin_ce_3m = "SI" if not (meses_ce_cliente & meses_recientes) else "NO"
            sin_ce_2026 = "SI" if not meses_ce_cliente else "NO"

        necesita_revision = "SI" if (
            a1 != "NO" or a2 == "SI" or sin_ce_3m == "SI" or sin_ce_2026 == "SI"
        ) else "NO"

        filas.append({
            "codunicocli": cu,
            "cliente_nuevo_sin_historico": "SI" if nuevo else "NO",
            "meses_con_gestion": meses_gestion,
            "mes_ultimo_ce": mes_reciente,
            "telefono_ultimo_ce": tlf_reciente,
            "A1_score_mal_priorizado": a1,
            "A2_telefono_no_asignado": a2,
            "sin_ce_ultimos_3_meses": sin_ce_3m,
            "sin_ce_todo_2026": sin_ce_2026,
            "necesita_revision": necesita_revision,
        })

    return pd.DataFrame(filas)


# ---------------------------------------------------------------------------
# Rutas Flask
# ---------------------------------------------------------------------------
@app.route("/", methods=["GET"])
def index():
    return render_template("index.html", resultado=None)


@app.route("/procesar", methods=["POST"])
def procesar():
    archivo = request.files.get("archivo_asignacion")
    if not archivo:
        return render_template("index.html", error="Sube un archivo primero.")

    try:
        asignacion_df = leer_asignacion(archivo)
        clientes = asignacion_df["codunicocli"].unique().tolist()

        historico_df = obtener_historico_ce(clientes)
        periodo_actual = datetime.now().strftime("%Y%m")
        meses_gestion_df = obtener_meses_con_gestion(clientes, periodo_actual)

        detalle = evaluar_clientes(asignacion_df, historico_df, meses_gestion_df, periodo_actual)
    except Exception as e:
        return render_template("index.html", error=f"Error procesando el archivo: {e}")

    total_clientes = detalle["codunicocli"].nunique()

    resumen = {
        "total_clientes": total_clientes,
        "clientes_con_alerta": (detalle["necesita_revision"] == "SI").sum(),
        "cant_A1": (detalle["A1_score_mal_priorizado"] != "NO").sum(),
        "cant_A2": (detalle["A2_telefono_no_asignado"] == "SI").sum(),
        "cant_sin_ce_3m": (detalle["sin_ce_ultimos_3_meses"] == "SI").sum(),
        "cant_sin_ce_2026": (detalle["sin_ce_todo_2026"] == "SI").sum(),
        "cant_nuevos": (detalle["cliente_nuevo_sin_historico"] == "SI").sum(),
    }

    # --- Auto-chequeo: si el resultado "huele mal", avisamos ANTES de
    # que se confíe en exportar/enviar nada. ---
    clientes_con_algun_ce = historico_df["codunicocli"].nunique() if len(historico_df) else 0
    pct_nuevos = (resumen["cant_nuevos"] / total_clientes) if total_clientes else 0

    advertencia_datos = None
    if total_clientes > 0 and clientes_con_algun_ce == 0:
        advertencia_datos = (
            f"⚠️ NO llegó ningún dato histórico de SQL Server para estos {total_clientes} "
            "clientes. Esto casi seguro es un problema de conexión/consulta, NO que "
            "ningún cliente tenga historial. No exportes ni envíes este resultado "
            "todavía -- corre diagnostico_cliente_puntual.sql para un cliente que "
            "sepas que sí tiene historial y compáralo."
        )
    elif pct_nuevos > 0.30:
        advertencia_datos = (
            f"⚠️ El {pct_nuevos:.0%} de los clientes salió como 'nuevo sin histórico'. "
            "Si sabes que muchos de ellos SÍ tienen contactos de meses anteriores, "
            "esto es señal de que la consulta no está trayendo bien los datos. "
            "Antes de exportar/enviar, corre diagnostico_cliente_puntual.sql con "
            "2-3 codunicocli que conozcas y confirma que sí traen su historial."
        )

    ULTIMO_RESULTADO["df"] = detalle
    ULTIMO_RESULTADO["generado"] = datetime.now().strftime("%d/%m/%Y %H:%M")
    ULTIMO_RESULTADO["resumen"] = resumen

    detalle_ordenado = detalle.sort_values(
        by=["necesita_revision", "codunicocli"], ascending=[False, True]
    )
    tabla_html = detalle_ordenado.to_html(index=False, classes="tabla-alertas", border=0)

    return render_template(
        "index.html",
        resultado=resumen,
        tabla_html=tabla_html,
        generado=ULTIMO_RESULTADO["generado"],
        advertencia_datos=advertencia_datos,
    )


def _armar_excel_alertas():
    """Genera el Excel de detalle en memoria. Devuelve (buffer, nombre)."""
    df = ULTIMO_RESULTADO["df"]
    if df is None or df.empty:
        return None, None

    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        df.sort_values(
            by=["necesita_revision", "codunicocli"], ascending=[False, True]
        ).to_excel(writer, index=False, sheet_name="alertas")
    buffer.seek(0)
    nombre = f"alertas_telefonos_bpe_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
    return buffer, nombre


@app.route("/exportar")
def exportar():
    buffer, nombre = _armar_excel_alertas()
    if buffer is None:
        return "No hay resultados para exportar todavía.", 400

    return send_file(
        buffer,
        as_attachment=True,
        download_name=nombre,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5001)
