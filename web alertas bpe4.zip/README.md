# Alertas de Teléfonos - BPE

Web mínima (Flask) para subir la asignación del día y detectar:

- **A1_SCORE_MAL_PRIORIZADO**: el teléfono del *ce* más reciente del
  cliente (no el que más veces contactó, sino el más cercano en el
  tiempo) existe en la asignación, pero no está en `telefono1`.
- **A2_TELEFONO_NO_ASIGNADO**: el teléfono del ce más reciente ni
  siquiera viene en la asignación de hoy.
- **B1_SIN_CONTACTO_3_ULTIMOS_MESES**: el cliente no tuvo ningún ce en
  los últimos 3 meses (pero sí tuvo antes).
- **B2_SIN_CONTACTO_6_ULTIMOS_MESES**: el cliente no tuvo ningún ce en
  los últimos 6 meses (pero sí tuvo antes).
- **B3_NUNCA_CONTACTO_EFECTIVO**: el cliente nunca tuvo un ce en todo el
  histórico consultado (desde enero) **y ya lleva más de 1 mes
  asignado** (se verifica contra `cob_trf_bpe_asignacion_historico`).
- **SIN_HISTORICO_CLIENTE_NUEVO**: el cliente nunca tuvo ce, pero es su
  primer mes en la asignación (recién ingresó) — no cuenta como alerta,
  es informativo, porque no ha pasado tiempo suficiente para juzgarlo.

B1/B2/B3/SIN_HISTORICO son a nivel **cliente** (no por teléfono/posición)
— miran todo su histórico de meses (como las columnas enero..agosto de
tu Excel original) y clasifican qué tan reciente fue su último contacto
efectivo. Reemplazan a la vieja alerta "A3" que era por teléfono.

## Instalación

```bash
cd web_alertas_bpe
python -m venv venv
venv\Scripts\activate        # en Windows
pip install -r requirements.txt
```

Revisa en `app.py` las constantes al inicio:

```python
DB_SERVER = r"s528vp04\bdt"
DB_NAME = "gic"
```

Si tu conexión no es con usuario de Windows (Trusted_Connection), cambia
`get_conn()` en `app.py` por usuario/contraseña SQL.

## Correr

```bash
python app.py
```

Abre `http://localhost:5000` en el navegador.

## Uso

1. Sube el Excel de asignación del día. Debe tener como mínimo las
   columnas `codunicocli`, `telefono1` ... `telefono10` (no importa si
   tiene más columnas, se ignoran).
2. La app trae de SQL Server SOLO el histórico de ce de esos clientes
   (usa una tabla temporal para el filtro, así no escanea toda la base
   cada vez).
3. Verás los KPIs (cuántos A1, A2, A3) y la tabla detalle.
4. Botón "Exportar detalle a Excel" te descarga el archivo con
   `codunicocli`, `telefono`, `posicion`, `tipo_alerta` para tus
   validaciones o para mandarlo al área de asignación.
5. Botón "Descargar imagen del dashboard" te guarda un .png con las
   tarjetas de KPI tal como se ven en pantalla (usa `html2canvas`, todo
   se genera en el navegador, no requiere nada del backend). Esa imagen
   la adjuntas tú manualmente donde la necesites (correo, chat, etc).

## Notas / próximos pasos sugeridos

- Ahora mismo el histórico de ce se consulta en vivo, cada vez que subes
  un archivo. Si con el tiempo se pone lento (mucho volumen), la
  siguiente mejora natural es dejar una tabla pre-calculada en SQL
  Server actualizada 1 vez al día, y que la app solo lea de ahí.
- El resultado exportado se guarda en memoria del proceso Flask
  (`ULTIMO_RESULTADO`); si esta web la van a usar varias personas a la
  vez, conviene guardar cada resultado con un id de sesión o en disco.
