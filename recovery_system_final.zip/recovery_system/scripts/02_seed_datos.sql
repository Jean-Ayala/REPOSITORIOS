-- ================================================================
-- Sistema Recovery — Script 02: Datos iniciales
-- ================================================================
USE gic_recovery;
GO

-- ──────────────────────────────────────────────────────────────
-- USUARIOS (1 supervisor + 17 gestores)
-- ──────────────────────────────────────────────────────────────
DELETE FROM usuarios WHERE username IN (
    'supervisor',
    'gestor01','gestor02','gestor03','gestor04','gestor05',
    'gestor06','gestor07','gestor08','gestor09','gestor10',
    'gestor11','gestor12','gestor13','gestor14','gestor15',
    'gestor16','gestor17'
);

INSERT INTO usuarios (username, password, rol, nombre_completo) VALUES
('supervisor', 'super2024',  'supervisor', 'Supervisor Recovery'),
('gestor01',   'g01pass',    'gestor',     'Ana Ríos'),
('gestor02',   'g02pass',    'gestor',     'Carlos Vera'),
('gestor03',   'g03pass',    'gestor',     'Diana Lara'),
('gestor04',   'g04pass',    'gestor',     'Edgar Fuentes'),
('gestor05',   'g05pass',    'gestor',     'Fátima Cruz'),
('gestor06',   'g06pass',    'gestor',     'Gonzalo Pino'),
('gestor07',   'g07pass',    'gestor',     'Hilda Mora'),
('gestor08',   'g08pass',    'gestor',     'Ivan Soto'),
('gestor09',   'g09pass',    'gestor',     'Julia Cano'),
('gestor10',   'g10pass',    'gestor',     'Kevin Rojas'),
('gestor11',   'g11pass',    'gestor',     'Laura Meza'),
('gestor12',   'g12pass',    'gestor',     'Mario Díaz'),
('gestor13',   'g13pass',    'gestor',     'Nadia Torres'),
('gestor14',   'g14pass',    'gestor',     'Oscar Reyes'),
('gestor15',   'g15pass',    'gestor',     'Paula Nieto'),
('gestor16',   'g16pass',    'gestor',     'Raúl Quispe'),
('gestor17',   'g17pass',    'gestor',     'Sara Vega');
GO

-- ──────────────────────────────────────────────────────────────
-- CAMPAÑAS DE EJEMPLO
-- ──────────────────────────────────────────────────────────────
DELETE FROM campanas;

INSERT INTO campanas (nombre, descripcion, monto_minimo, fecha_inicio, fecha_fin, creado_por)
SELECT 'Campaña Verano 2025',
       'Condonación de intereses por pago mínimo — Q1 2025',
       500.00, '2025-01-01', '2025-03-31', id
FROM usuarios WHERE username = 'supervisor';

INSERT INTO campanas (nombre, descripcion, monto_minimo, fecha_inicio, fecha_fin, creado_por)
SELECT 'Campaña Reactívate Q2 2025',
       'Reactivación clientes inactivos — pago al contado',
       1000.00, '2025-04-01', '2025-06-30', id
FROM usuarios WHERE username = 'supervisor';

INSERT INTO campanas (nombre, descripcion, monto_minimo, fecha_inicio, fecha_fin, creado_por)
SELECT 'Campaña Recovery Julio 2025',
       'Campaña mensual — monto mínimo para condonación de mora',
       300.00, '2025-07-01', '2025-07-31', id
FROM usuarios WHERE username = 'supervisor';

INSERT INTO campanas (nombre, descripcion, monto_minimo, fecha_inicio, fecha_fin, activa, creado_por)
SELECT 'Campaña Navidad 2024',
       'Promoción fin de año — ya cerrada',
       200.00, '2024-12-01', '2024-12-31', 0, id
FROM usuarios WHERE username = 'supervisor';
GO

-- ──────────────────────────────────────────────────────────────
-- PADRÓN MENSUAL DE EJEMPLO (20 cuentas para pruebas)
-- ──────────────────────────────────────────────────────────────
DECLARE @sup_id INT = (SELECT id FROM usuarios WHERE username='supervisor');
DECLARE @mes CHAR(7) = '2025-07';
DECLARE @lote UNIQUEIDENTIFIER = NEWID();

INSERT INTO padron_mensual (cu, cj, nombre_cliente, producto, saldo_total, dias_mora, mes_carga, subido_por, lote_id)
VALUES
('CU-00012345','CJ-00123','Inversiones Pérez S.A.',          'Tarjeta Corporativa',  1250000.00, 120, @mes, @sup_id, @lote),
('CU-00045678','CJ-00456','Distribuidora Castillo E.I.R.L.', 'Préstamo Personal',      85000.00,  60, @mes, @sup_id, @lote),
('CU-00078901','CJ-00789','Fernández e Hijos SAC',           'Línea de Crédito',      320000.00,  90, @mes, @sup_id, @lote),
('CU-00112233','CJ-01122','Importaciones López S.A.',        'Tarjeta Corporativa',   560000.00, 180, @mes, @sup_id, @lote),
('CU-00334455','CJ-03344','Corporación Siena SRL',           'Préstamo Hipotecario', 2100000.00,  45, @mes, @sup_id, @lote),
('CU-00556677','CJ-05566','Tech Solutions Perú',             'Préstamo Personal',      42000.00, 120, @mes, @sup_id, @lote),
('CU-00778899','CJ-07788','Grupo Portales E.I.R.L.',        'Tarjeta Corporativa',   780000.00,  75, @mes, @sup_id, @lote),
('CU-00990011','CJ-09900','Maquinaria del Sur SAC',          'Arrendamiento',         950000.00, 200, @mes, @sup_id, @lote),
('CU-01122334','CJ-11223','Agro Exportaciones Andes',        'Préstamo Agrario',      135000.00,  30, @mes, @sup_id, @lote),
('CU-01334455','CJ-13344','Logística Norte SAC',             'Línea de Crédito',      290000.00,  60, @mes, @sup_id, @lote),
('CU-01556677','CJ-15566','Constructora Alianza Perú',       'Préstamo Hipotecario', 4500000.00, 150, @mes, @sup_id, @lote),
('CU-01778899','CJ-17788','Textiles San Marcos',             'Tarjeta Corporativa',   180000.00,  90, @mes, @sup_id, @lote),
('CU-01990011','CJ-19900','Servicios Integrados ABC',        'Préstamo Personal',      67000.00,  45, @mes, @sup_id, @lote),
('CU-02112233','CJ-21122','Exportadora Pacífico SAC',        'Línea de Crédito',      830000.00, 120, @mes, @sup_id, @lote),
('CU-02334455','CJ-23344','Minera Santa Rosa E.I.R.L.',      'Arrendamiento',        1650000.00,  60, @mes, @sup_id, @lote),
('CU-02556677','CJ-25566','Inversiones El Roble',            'Préstamo Personal',      55000.00,  30, @mes, @sup_id, @lote),
('CU-02778899','CJ-27788','Inmobiliaria Los Pinos',          'Préstamo Hipotecario', 3200000.00, 180, @mes, @sup_id, @lote),
('CU-02990011','CJ-29900','Comercial Unión Andina',          'Tarjeta Corporativa',   410000.00,  75, @mes, @sup_id, @lote),
('CU-03112233','CJ-31122','Distribuidora Novo SAC',          'Línea de Crédito',      195000.00,  45, @mes, @sup_id, @lote),
('CU-03334455','CJ-33344','Consorcio Vial Perú',             'Arrendamiento',        2750000.00, 210, @mes, @sup_id, @lote);
GO

PRINT '====================================================';
PRINT 'Datos iniciales insertados:';
PRINT '  - 18 usuarios (1 supervisor + 17 gestores)';
PRINT '  - 4 campañas (3 activas + 1 inactiva)';
PRINT '  - 20 cuentas en padrón Julio 2025';
PRINT '====================================================';
PRINT '';
PRINT 'CREDENCIALES:';
PRINT '  supervisor / super2024';
PRINT '  gestor01   / g01pass   ... gestor17 / g17pass';
