import os, uuid, pandas as pd
from datetime import datetime
from werkzeug.utils import secure_filename
from app.config import Config

# ── Archivo ────────────────────────────────────────────────────
def allowed(filename):
    return '.' in filename and filename.rsplit('.',1)[1].lower() in Config.ALLOWED_EXCEL

def save_file(file, sub=''):
    base = os.path.join(Config.UPLOAD_FOLDER, sub)
    os.makedirs(base, exist_ok=True)
    ext  = file.filename.rsplit('.',1)[-1].lower()
    name = f"{uuid.uuid4().hex}.{ext}"
    path = os.path.join(base, name)
    file.save(path)
    return name, path

# ── Lector de Excel masivo ─────────────────────────────────────
COL_MAP = {
    'cu':       ['cu','cuenta_unica','cuenta unica','cod_cuenta'],
    'cj':       ['cj','codigo_juicio','cod_juicio','juicio'],
    'nombre':   ['nombre','nombre_cliente','cliente','nombres'],
    'producto': ['producto','tipo_producto','tipo producto'],
    'saldo':    ['saldo_total','saldo','capital','monto','monto_capital','deuda'],
    'mora':     ['dias_mora','mora','dias mora','dias_atraso'],
}

def _norm(s): return str(s).strip().lower().replace(' ','_').replace('-','_')

def detectar_cols(df_cols):
    norm = {_norm(c): c for c in df_cols}
    res  = {}
    for campo, alias in COL_MAP.items():
        for a in alias:
            if _norm(a) in norm:
                res[campo] = norm[_norm(a)]; break
    return res

def leer_excel_padron(ruta):
    try:
        ext = ruta.rsplit('.',1)[-1].lower()
        df  = pd.read_csv(ruta, dtype=str, encoding='utf-8-sig', low_memory=False) \
              if ext=='csv' else pd.read_excel(ruta, dtype=str, engine='openpyxl')
        df.columns = [str(c).strip() for c in df.columns]
        mapa = detectar_cols(df.columns.tolist())
        if 'cu' not in mapa and 'nombre' not in mapa:
            return [], 0, 0, (f"No se encontraron columnas reconocibles. "
                              f"Detectadas: {', '.join(df.columns[:8])}. "
                              f"Se esperan: CU, CJ, NOMBRE, SALDO_TOTAL, etc.")
        filas, err = [], 0
        for _, row in df.iterrows():
            def g(k):
                col = mapa.get(k)
                v   = str(row.get(col,'') if col else '').strip()
                return None if v in ('','nan','None') else v
            cu = g('cu'); nom = g('nombre')
            if not cu or not nom: err+=1; continue
            try:    saldo = float((g('saldo') or '0').replace(',','').replace('S/','').strip())
            except: saldo = 0.0
            try:    mora = int(float(g('mora'))) if g('mora') else None
            except: mora = None
            filas.append((cu[:30],(g('cj') or '')[:30],nom[:150],
                          (g('producto') or '')[:80], saldo, mora))
        return filas, len(filas), err, None
    except Exception as e:
        return [], 0, 0, f"Error al leer archivo: {e}"

# ── Exportar a Excel ───────────────────────────────────────────
def exportar_excel(registros):
    base = os.path.join(Config.UPLOAD_FOLDER, 'exports')
    os.makedirs(base, exist_ok=True)
    nombre = f"recovery_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    ruta   = os.path.join(base, nombre)
    COL = {
        'id':'ID','cu':'CU','cj':'CJ','nombre_cliente':'Cliente',
        'producto':'Producto','saldo_total':'Saldo Total (S/)',
        'pago_realizado':'Pago Realizado (S/)','monto_minimo_camp':'Monto Mínimo (S/)',
        'monto_a_condonar':'A Condonar (S/)','diferencia_pago':'Diferencia (S/)',
        'pago_conforme':'Pago OK','estado':'Estado','campana':'Campaña',
        'gestor_nombre':'Gestor','gestor_user':'Usuario',
        'fecha_creacion':'Fecha Creación','fecha_envio':'Fecha Envío',
    }
    df = pd.DataFrame(registros).rename(columns={k:v for k,v in COL.items() if k in pd.DataFrame(registros).columns})
    if 'Pago OK' in df.columns:
        df['Pago OK'] = df['Pago OK'].apply(lambda x: 'SÍ' if x else 'NO')
    orden = [v for v in COL.values() if v in df.columns]
    df[orden].to_excel(ruta, index=False, sheet_name='Recovery')
    return ruta, nombre

# ── Fecha helpers ──────────────────────────────────────────────
def mes_actual(): return datetime.now().strftime('%Y-%m')

def fmt_mes(m):
    meses=['Enero','Febrero','Marzo','Abril','Mayo','Junio',
           'Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre']
    try: y,n=m.split('-'); return f"{meses[int(n)-1]} {y}"
    except: return m
