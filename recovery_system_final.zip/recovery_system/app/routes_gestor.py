from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from app.auth import login_required, role_required, me, ip
from app.database import (crear_solicitud, editar_solicitud, cambiar_estado_solicitud,
                           get_solicitud, get_historial_solicitud, get_solicitudes_gestor,
                           get_campanas_activas, buscar_en_padron, log)
from app.utils import mes_actual, fmt_mes
from app.config import Config

ges_bp = Blueprint('ges', __name__)
ESTADOS = ['Borrador','Enviado','Aprobado','Rechazado','Observado']


@ges_bp.route('/dashboard')
@role_required('gestor')
def dashboard():
    u = me()
    solicitudes, total = get_solicitudes_gestor(u['id'], page=1, per_page=8)
    return render_template('ges_dashboard.html', user=u,
                           solicitudes=solicitudes, total=total,
                           mes=mes_actual(), fmt_mes=fmt_mes)


@ges_bp.route('/nueva', methods=['GET','POST'])
@role_required('gestor')
def nueva():
    u        = me()
    campanas = get_campanas_activas()
    if request.method == 'POST':
        action = request.form.get('action','borrador')
        cu     = request.form.get('cu','').strip()
        if not cu:
            flash('El CU es obligatorio.','danger')
            return redirect(url_for('ges.nueva'))
        try:
            d = {
                'cu':                cu,
                'cj':                request.form.get('cj','').strip(),
                'nombre_cliente':    request.form.get('nombre_cliente','').strip() or 'Sin nombre',
                'producto':          request.form.get('producto',''),
                'saldo_total':       float(request.form.get('saldo_total',0) or 0),
                'dias_mora':         request.form.get('dias_mora') or None,
                'campana_id':        int(request.form.get('campana_id',0)),
                'monto_minimo_camp': float(request.form.get('monto_minimo_camp',0) or 0),
                'pago_realizado':    float(request.form.get('pago_realizado',0) or 0),
                'monto_a_condonar':  float(request.form.get('monto_a_condonar',0) or 0),
                'observacion_gestor':request.form.get('observacion_gestor',''),
                'gestor_id':         u['id'],
                'estado':            'Enviado' if action=='enviar' else 'Borrador',
                'mes_referencia':    mes_actual(),
            }
        except (ValueError, TypeError) as e:
            flash(f'Error en los datos: {e}','danger')
            return redirect(url_for('ges.nueva'))

        sid = crear_solicitud(d)
        log(u['id'],'SOLICITUD_CREADA',
            f"SID={sid}|CU={cu}|Estado={d['estado']}|Pago={d['pago_realizado']}|Min={d['monto_minimo_camp']}",
            tabla='solicitudes', id_ref=sid, ip=ip())
        flash(f'Solicitud #{sid} {"enviada" if d["estado"]=="Enviado" else "guardada como borrador"}.','success')
        return redirect(url_for('ges.mis_solicitudes'))

    return render_template('ges_form.html', user=u, campanas=campanas,
                           solicitud=None, modo='nueva', mes=mes_actual())


@ges_bp.route('/editar/<int:sid>', methods=['GET','POST'])
@role_required('gestor')
def editar(sid):
    u         = me()
    solicitud = get_solicitud(sid)
    if not solicitud or solicitud['gestor_id'] != u['id']:
        flash('No encontrada.','danger'); return redirect(url_for('ges.mis_solicitudes'))
    if solicitud['estado'] != 'Borrador':
        flash('Solo puedes editar borradores.','warning')
        return redirect(url_for('ges.ver', sid=sid))
    campanas = get_campanas_activas()
    if request.method == 'POST':
        action = request.form.get('action','borrador')
        try:
            d = {
                'cu':               request.form.get('cu','').strip(),
                'cj':               request.form.get('cj','').strip(),
                'nombre_cliente':   request.form.get('nombre_cliente','').strip(),
                'producto':         request.form.get('producto',''),
                'saldo_total':      float(request.form.get('saldo_total',0) or 0),
                'dias_mora':        request.form.get('dias_mora') or None,
                'campana_id':       int(request.form.get('campana_id',0)),
                'monto_minimo_camp':float(request.form.get('monto_minimo_camp',0) or 0),
                'pago_realizado':   float(request.form.get('pago_realizado',0) or 0),
                'monto_a_condonar': float(request.form.get('monto_a_condonar',0) or 0),
                'observacion_gestor':request.form.get('observacion_gestor',''),
            }
        except (ValueError,TypeError) as e:
            flash(f'Error: {e}','danger'); return redirect(url_for('ges.editar',sid=sid))
        editar_solicitud(sid, d, u['id'])
        if action=='enviar':
            cambiar_estado_solicitud(sid,'Enviado',u['id'],'Enviado por gestor')
            flash(f'Solicitud #{sid} enviada.','success')
        else:
            flash('Cambios guardados.','success')
        return redirect(url_for('ges.mis_solicitudes'))
    return render_template('ges_form.html', user=u, campanas=campanas,
                           solicitud=solicitud, modo='editar', mes=mes_actual())


@ges_bp.route('/mis-solicitudes')
@role_required('gestor')
def mis_solicitudes():
    u      = me()
    page   = int(request.args.get('page',1))
    estado = request.args.get('estado','')
    solicitudes, total = get_solicitudes_gestor(u['id'], page=page, estado=estado or None)
    pages = (total + Config.ROWS_PER_PAGE - 1) // Config.ROWS_PER_PAGE
    return render_template('ges_lista.html', user=u,
                           solicitudes=solicitudes, total=total,
                           page=page, pages=pages, estado=estado, ESTADOS=ESTADOS)


@ges_bp.route('/ver/<int:sid>')
@role_required('gestor')
def ver(sid):
    u = me()
    s = get_solicitud(sid)
    if not s or s['gestor_id'] != u['id']:
        flash('Sin acceso.','danger'); return redirect(url_for('ges.mis_solicitudes'))
    h = get_historial_solicitud(sid)
    return render_template('detalle.html', user=u, s=s, historial=h)


# ── API AJAX ─────────────────────────────────────────────────
@ges_bp.route('/api/buscar-cu')
@role_required('gestor')
def api_buscar_cu():
    cu  = request.args.get('cu','').strip()
    cj  = request.args.get('cj','').strip()
    mes = mes_actual()
    if not cu: return jsonify({'found':False})
    dato = buscar_en_padron(cu, cj or None, mes)
    if dato:
        return jsonify({'found':True,
                        'nombre_cliente': dato['nombre_cliente'],
                        'producto':       dato['producto'] or '',
                        'saldo_total':    dato['saldo_total'],
                        'monto_maximo':   dato.get('monto_maximo', dato['saldo_total']),
                        'monto_minimo':   dato.get('monto_minimo', 0),
                        'dias_mora':      dato['dias_mora'] or ''})
    return jsonify({'found':False})
