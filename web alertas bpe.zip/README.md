# Alertas de Teléfonos - BPE

Web mínima (Flask) para subir la asignación del día y detectar:

- **A1_SCORE_MAL_PRIORIZADO**: el teléfono que sí tuvo contacto efectivo (ce)
  histórico existe en la asignación, pero no está en `telefono1`.
- **A2_TELEFONO_NO_ASIGNADO**: el teléfono que sí tuvo ce histórico ni
  siquiera viene en la asignación de hoy.
- **A3_TELEFONO_SIN_CONTACTO**: un teléfono que sí te asignan hoy (en
  cualquier posición) nunca generó un ce en el histórico.

## Instalación

```bash
cd web_alertas_bpe
python -m venv venv
venv\Scripts\activate        # en Windows
pip install -r requirements.txt
```

Revisa en `app.py` las constantes al inicio:

```python
DB_SERVER = r"s528vp04\bdt"
DB_NAME = "gic"
```

Si tu conexión no es con usuario de Windows (Trusted_Connection), cambia
`get_conn()` en `app.py` por usuario/contraseña SQL.

## Correr

```bash
python app.py
```

Abre `http://localhost:5000` en el navegador.

## Uso

1. Sube el Excel de asignación del día. Debe tener como mínimo las
   columnas `codunicocli`, `telefono1` ... `telefono10` (no importa si
   tiene más columnas, se ignoran).
2. La app trae de SQL Server SOLO el histórico de ce de esos clientes
   (usa una tabla temporal para el filtro, así no escanea toda la base
   cada vez).
3. Verás los KPIs (cuántos A1, A2, A3) y la tabla detalle.
4. Botón "Exportar detalle a Excel" te descarga el archivo con
   `codunicocli`, `telefono`, `posicion`, `tipo_alerta` para tus
   validaciones o para mandarlo al área de asignación.
5. Botón "Descargar imagen del dashboard" te guarda un .png con las
   tarjetas de KPI tal como se ven en pantalla (usa `html2canvas`, todo
   se genera en el navegador, no requiere nada del backend). Esa imagen
   la adjuntas tú manualmente donde la necesites (correo, chat, etc).

## Notas / próximos pasos sugeridos

- Ahora mismo el histórico de ce se consulta en vivo, cada vez que subes
  un archivo. Si con el tiempo se pone lento (mucho volumen), la
  siguiente mejora natural es dejar una tabla pre-calculada en SQL
  Server actualizada 1 vez al día, y que la app solo lea de ahí.
- El resultado exportado se guarda en memoria del proceso Flask
  (`ULTIMO_RESULTADO`); si esta web la van a usar varias personas a la
  vez, conviene guardar cada resultado con un id de sesión o en disco.
