"""
Web de Alertas de Teléfonos - BPE
----------------------------------
Flujo:
  1. Usuario sube el Excel de asignación del día (columnas: codunicocli,
     telefono1..telefono10, y lo que tenga la asignación).
  2. La app limpia esos teléfonos y arma la lista de codunicocli.
  3. Consulta SQL Server SOLO el histórico de contacto efectivo (ce) de
     esos clientes (enero..mes actual), usando una tabla temporal para
     que el filtro sea rápido aunque subas miles de clientes.
  4. Cruza en pandas: para cada cliente, ¿el teléfono que contactó
     está en telefono1? ¿en otra posición? ¿ni siquiera está asignado?
     ¿hay teléfonos asignados que nunca contactaron?
  5. Muestra un dashboard con los conteos + tabla detalle + botón exportar.

Cómo correr:
    pip install -r requirements.txt
    python app.py
    abrir http://localhost:5000
"""

import io
import os
from datetime import datetime

import pandas as pd
import pyodbc
from flask import Flask, render_template, request, send_file, session

app = Flask(__name__)
app.secret_key = "cambia-esto-por-algo-seguro"

# ---------------------------------------------------------------------------
# CONFIGURACIÓN DE CONEXIÓN - ajusta si tu driver/instancia es distinto
# ---------------------------------------------------------------------------
DB_SERVER = r"s528vp04\bdt"
DB_NAME = "gic"
CAMPANAS = ("cob_bpe_00", "cob_bpe_01", "cob_bpe_02")
MES_DESDE = "202601"  # arranque del histórico

# Guardamos el último resultado en memoria para poder exportarlo.
# Para un solo usuario local esto es suficiente; si la usan varias
# personas a la vez, mejor guardar en disco/DB con un id de sesión.
ULTIMO_RESULTADO = {"df": None, "generado": None, "resumen": None}


def get_conn():
    conn_str = (
        "DRIVER={ODBC Driver 17 for SQL Server};"
        f"SERVER={DB_SERVER};DATABASE={DB_NAME};Trusted_Connection=yes;"
    )
    return pyodbc.connect(conn_str)


def limpiar_numero(valor):
    """Normaliza códigos de cliente y teléfonos que vienen del Excel.
    Pandas suele leer estas columnas como float (ej. 990356503.0), y si
    solo hacemos str(valor) queda "990356503.0" -- ese ".0" hace que la
    comparación contra el histórico de SQL (que sí viene limpio) NUNCA
    calce, y todo termina marcado como "sin contacto" aunque sí lo tuvo.
    Esta función deja solo dígitos, sin decimales ni espacios.
    Devuelve None si no queda ningún dígito válido (o es puro cero).
    """
    if pd.isna(valor):
        return None
    texto = str(valor).strip()
    if texto.endswith(".0"):
        texto = texto[:-2]
    texto = "".join(ch for ch in texto if ch.isdigit())
    if texto == "" or texto == "0":
        return None
    return texto


def leer_asignacion(file_storage):
    """Lee el Excel subido y devuelve un DataFrame limpio:
    codunicocli, posicion (1-10), telefono (solo filas con teléfono válido).
    """
    df = pd.read_excel(file_storage)
    df.columns = [c.strip().lower() for c in df.columns]

    if "codunicocli" not in df.columns:
        raise ValueError("El Excel debe tener una columna 'codunicocli'.")

    cols_tlf = [f"telefono{i}" for i in range(1, 11) if f"telefono{i}" in df.columns]
    if not cols_tlf:
        raise ValueError("No encontré columnas telefono1..telefono10 en el Excel.")

    filas = []
    for _, row in df.iterrows():
        cu = limpiar_numero(row["codunicocli"])
        if cu is None:
            continue
        for i, col in enumerate(cols_tlf, start=1):
            tel = limpiar_numero(row[col])
            if tel is None:
                continue
            filas.append({"codunicocli": cu, "posicion": i, "telefono": tel})

    return pd.DataFrame(filas)


def obtener_historico_ce(codunicoclis):
    """Trae de SQL Server el histórico de contacto efectivo SOLO para
    los clientes de la lista, usando una tabla temporal para el filtro."""
    if not codunicoclis:
        return pd.DataFrame(columns=["codunicocli", "mes", "telefono"])

    codunicoclis = list({c for c in (limpiar_numero(x) for x in codunicoclis) if c is not None})

    conn = get_conn()
    cursor = conn.cursor()
    cursor.fast_executemany = True

    cursor.execute("CREATE TABLE #clientes_hoy (codunicocli VARCHAR(50))")
    cursor.executemany(
        "INSERT INTO #clientes_hoy (codunicocli) VALUES (?)",
        [(c,) for c in codunicoclis],
    )
    conn.commit()

    query = f"""
        with tipis as (
            select
                periodo as mes,
                [contact id] as codunicocli,
                [wrap-up],
                right(dnis,9) as telefono,
                orden = row_number() over (partition by [contact id], periodo order by fecha_key asc)
            from ykr_tb_cob_intentos as a
            inner join #clientes_hoy ch
                on ltrim(rtrim(cast(a.[contact id] as varchar(50)))) = ch.codunicocli
            left join (
                select conlusion_cloud as conclusion, 1 as resultado
                from ob_conclusiones_cloud_5
                where tipo_resultado in ('pdp','pdp - fdp','contacto - efectivo')
            ) as b on b.conclusion = a.[wrap-up]
            -- OJO: se agrega el "or" de respaldo porque si en el mes en
            -- curso usan un wrap-up nuevo que TODAVÍA no está mapeado en
            -- ob_conclusiones_cloud_5, el inner join lo descartaba
            -- silenciosamente y el cliente salía como "nunca contactado"
            -- aunque sí tuvo ce ese mismo mes. Confirma con el área dueña
            -- de esa tabla catálogo si detectas wrap-ups nuevos sin mapear.
            where (b.resultado = 1
                   or lower(ltrim(rtrim(a.[wrap-up]))) in ('pdp','pdp - fdp','contacto - efectivo'))
              and [campaign name] in {CAMPANAS}

            union all

            select
                periodo as mes,
                [contact id] as codunicocli,
                [wrap-up],
                right(dnis,9) as telefono,
                orden = row_number() over (partition by [contact id], periodo order by fecha_key asc)
            from ykr_tb_cob_intentos_bkp as a
            inner join #clientes_hoy ch
                on ltrim(rtrim(cast(a.[contact id] as varchar(50)))) = ch.codunicocli
            left join (
                select conlusion_cloud as conclusion, 1 as resultado
                from ob_conclusiones_cloud_5
                where tipo_resultado in ('pdp','pdp - fdp','contacto - efectivo')
            ) as b on b.conclusion = a.[wrap-up]
            where (b.resultado = 1
                   or lower(ltrim(rtrim(a.[wrap-up]))) in ('pdp','pdp - fdp','contacto - efectivo'))
              and [campaign name] in {CAMPANAS}
              and cast(periodo as int) >= {MES_DESDE}
        )
        select codunicocli, mes, telefono
        from tipis
        where orden = 1;
    """
    hist = pd.read_sql(query, conn)
    conn.close()

    hist.columns = [c.lower() for c in hist.columns]
    hist["codunicocli"] = hist["codunicocli"].apply(limpiar_numero)
    hist["telefono"] = hist["telefono"].apply(limpiar_numero)
    hist = hist.dropna(subset=["codunicocli", "telefono"])
    return hist


def cruzar_alertas(asignacion_df, historico_df):
    """Devuelve el detalle de alertas A1/A2 por cliente.
    Ambos DataFrames ya llegan con codunicocli/telefono limpios
    (puros dígitos, sin .0) desde leer_asignacion() y obtener_historico_ce().

    Criterio A1/A2: por cada cliente se identifica el teléfono del MES
    MÁS RECIENTE con ce (no el que más veces contactó, sino el más
    cercano en el tiempo) -- ese es "el que debería estar en telefono1".
    Si Pepito contactó en enero-marzo-mayo con el tlf A, pero en
    junio-julio contactó con el tlf B, se prioriza B por ser más
    reciente, aunque A tenga más meses de contacto.
    """
    asignacion_df = asignacion_df.copy()

    # --- A1 y A2: 1 fila por cliente, con el teléfono de su ce más reciente ---
    # Se usa idxmax() sobre el mes convertido a número (en vez de
    # sort_values().last()) para evitar que un cliente con filas
    # duplicadas del mismo mes (una viniendo de la tabla principal y
    # otra del backup) termine "empujando" por error un mes viejo como
    # si fuera el más reciente.
    historico_df = historico_df.copy()
    historico_df["mes_num"] = historico_df["mes"].apply(_periodo_a_num_meses)
    idx_mas_reciente = historico_df.groupby("codunicocli")["mes_num"].idxmax()
    telefono_reciente = historico_df.loc[
        idx_mas_reciente, ["codunicocli", "mes", "telefono"]
    ].rename(columns={"telefono": "telefono_reciente", "mes": "mes_reciente"})

    cruce = telefono_reciente.merge(
        asignacion_df[["codunicocli", "posicion", "telefono"]],
        left_on=["codunicocli", "telefono_reciente"],
        right_on=["codunicocli", "telefono"],
        how="left",
    )

    def flag_priorizacion(row):
        if pd.isna(row["posicion"]):
            return "A2_TELEFONO_NO_ASIGNADO"
        elif int(row["posicion"]) == 1:
            return "ok"
        else:
            return "A1_SCORE_MAL_PRIORIZADO"

    cruce["tipo_alerta"] = cruce.apply(flag_priorizacion, axis=1)
    alertas_1_2 = cruce[cruce["tipo_alerta"] != "ok"][
        ["codunicocli", "telefono_reciente", "mes_reciente", "posicion", "tipo_alerta"]
    ].rename(columns={"telefono_reciente": "telefono"})

    return alertas_1_2


def _periodo_a_num_meses(periodo):
    """Convierte 'YYYYMM' (ej. '202608') a un entero de meses absolutos
    (año*12 + mes), para poder restar periodos y saber cuántos meses
    de diferencia hay entre dos de ellos."""
    periodo = str(periodo)
    return int(periodo[:4]) * 12 + int(periodo[4:6])


def obtener_meses_asignados(codunicoclis, periodo_actual):
    """Cuenta, para cada cliente, en cuántos meses distintos (desde
    MES_DESDE hasta el mes actual) apareció asignado en tramo
    temprana/intermedia/tardia dentro de cob_trf_bpe_asignacion_historico.
    Un cliente con meses_asignados <= 1 recién entró este mes: no hay
    histórico real todavía para juzgarlo como "nunca contactado".
    """
    if not codunicoclis:
        return pd.DataFrame(columns=["codunicocli", "meses_asignados"])

    codunicoclis = list({c for c in (limpiar_numero(x) for x in codunicoclis) if c is not None})

    conn = get_conn()
    cursor = conn.cursor()
    cursor.fast_executemany = True

    cursor.execute("CREATE TABLE #clientes_asig (codunicocli VARCHAR(50))")
    cursor.executemany(
        "INSERT INTO #clientes_asig (codunicocli) VALUES (?)",
        [(c,) for c in codunicoclis],
    )
    conn.commit()

    query = f"""
        select
            ch.codunicocli,
            count(distinct a.codmes) as meses_asignados
        from cob_trf_bpe_asignacion_historico a
        inner join #clientes_asig ch
            on ltrim(rtrim(cast(a.codunicocli as varchar(50)))) = ch.codunicocli
        where a.codmes between '{MES_DESDE}' and '{periodo_actual}'
          and a.tramo_asignacion in ('temprana','intermedia','tardia')
        group by ch.codunicocli;
    """
    df = pd.read_sql(query, conn)
    conn.close()

    df.columns = [c.lower() for c in df.columns]
    df["codunicocli"] = df["codunicocli"].apply(limpiar_numero)
    df = df.dropna(subset=["codunicocli"])
    return df


def clasificar_contacto_historico(asignacion_df, historico_df, meses_asignados_df, periodo_actual):
    """Clasifica a CADA CLIENTE (no por teléfono) según qué tan reciente
    fue su último contacto efectivo, mirando todo el histórico (enero en
    adelante) que trae obtener_historico_ce:

        - tuvo ce en los últimos 3 meses (incluye el mes actual)  -> ok, sin alerta
        - NO tuvo ce en los últimos 3 meses, pero sí en los 6      -> B1
        - NO tuvo ce en los últimos 6 meses, pero sí alguna vez    -> B2
        - NUNCA tuvo ce Y ya lleva más de 1 mes asignado           -> B3
        - NUNCA tuvo ce PERO es su primer mes asignado (cliente
          nuevo, sin base histórica todavía)                       -> SIN_HISTORICO
          (esta última NO cuenta como alerta real, es informativa)

    Esto reemplaza a la vieja alerta A3 (que era por teléfono/posición)
    por una lectura más útil a nivel cliente: "hace cuánto que no lo
    contactamos", igual que se veía en las columnas enero..agosto de
    tu Excel original.
    """
    mes_actual_num = _periodo_a_num_meses(periodo_actual)
    meses_map = dict(zip(meses_asignados_df["codunicocli"], meses_asignados_df["meses_asignados"]))

    historico_df = historico_df.copy()
    historico_df["mes_num"] = historico_df["mes"].apply(_periodo_a_num_meses)
    idx_mas_reciente = historico_df.groupby("codunicocli")["mes_num"].idxmax()
    ultimo_ce = historico_df.loc[idx_mas_reciente, ["codunicocli", "mes"]].rename(
        columns={"mes": "mes_ultimo_ce"}
    )
    ultimo_ce["meses_sin_contacto"] = ultimo_ce["mes_ultimo_ce"].apply(
        lambda m: mes_actual_num - _periodo_a_num_meses(m)
    )

    def clasificar(meses):
        if meses <= 2:
            return None  # tuvo ce dentro de los últimos 3 meses (mes actual, -1, -2)
        elif meses <= 5:
            return "B1_SIN_CONTACTO_3_ULTIMOS_MESES"
        else:
            return "B2_SIN_CONTACTO_6_ULTIMOS_MESES"

    ultimo_ce["tipo_alerta"] = ultimo_ce["meses_sin_contacto"].apply(clasificar)
    alertas_b1_b2 = ultimo_ce[ultimo_ce["tipo_alerta"].notna()][
        ["codunicocli", "mes_ultimo_ce", "tipo_alerta"]
    ]

    # --- clientes de la asignación que NO tienen ni una sola fila de ce
    #     en todo el histórico consultado: se separan en 2 grupos ---
    clientes_todos = set(asignacion_df["codunicocli"].unique())
    clientes_con_ce_alguna_vez = set(historico_df["codunicocli"].unique())
    clientes_sin_ce = clientes_todos - clientes_con_ce_alguna_vez

    filas_b3 = []
    filas_nuevos = []
    for cu in sorted(clientes_sin_ce):
        # si no aparece en meses_map, asumimos 0 (defensivo: mejor
        # tratarlo como "nuevo/sin datos" que como alerta grave)
        meses_asig = meses_map.get(cu, 0)
        if meses_asig <= 1:
            filas_nuevos.append(
                {"codunicocli": cu, "mes_ultimo_ce": None, "tipo_alerta": "SIN_HISTORICO_CLIENTE_NUEVO"}
            )
        else:
            filas_b3.append(
                {"codunicocli": cu, "mes_ultimo_ce": None, "tipo_alerta": "B3_NUNCA_CONTACTO_EFECTIVO"}
            )

    cols = ["codunicocli", "mes_ultimo_ce", "tipo_alerta"]
    alertas_b3 = pd.DataFrame(filas_b3, columns=cols)
    alertas_nuevos = pd.DataFrame(filas_nuevos, columns=cols)

    return pd.concat([alertas_b1_b2, alertas_b3, alertas_nuevos], ignore_index=True)


@app.route("/", methods=["GET"])
def index():
    return render_template("index.html", resultado=None)


@app.route("/procesar", methods=["POST"])
def procesar():
    archivo = request.files.get("archivo_asignacion")
    if not archivo:
        return render_template("index.html", error="Sube un archivo primero.")

    try:
        asignacion_df = leer_asignacion(archivo)
        historico_df = obtener_historico_ce(asignacion_df["codunicocli"].unique().tolist())

        periodo_actual = datetime.now().strftime("%Y%m")
        meses_asignados_df = obtener_meses_asignados(
            asignacion_df["codunicocli"].unique().tolist(), periodo_actual
        )

        alertas_a1_a2 = cruzar_alertas(asignacion_df, historico_df)
        alertas_b = clasificar_contacto_historico(
            asignacion_df, historico_df, meses_asignados_df, periodo_actual
        )

        # unificamos ambos resultados en una sola tabla de detalle;
        # A1/A2 traen telefono+posicion, B1/B2/B3/SIN_HISTORICO son a
        # nivel cliente (sin teléfono/posición puntual), por eso se
        # completan con None
        for col in ["telefono", "posicion"]:
            if col not in alertas_b.columns:
                alertas_b[col] = None
        detalle = pd.concat([alertas_a1_a2, alertas_b], ignore_index=True)
    except Exception as e:
        return render_template("index.html", error=f"Error procesando el archivo: {e}")

    total_clientes = asignacion_df["codunicocli"].nunique()
    # "sin histórico" es informativo, no cuenta como alerta real
    clientes_con_alerta = detalle[
        detalle.tipo_alerta != "SIN_HISTORICO_CLIENTE_NUEVO"
    ]["codunicocli"].nunique()

    resumen = {
        "total_clientes": total_clientes,
        "clientes_con_alerta": clientes_con_alerta,
        "cant_A1": detalle[detalle.tipo_alerta == "A1_SCORE_MAL_PRIORIZADO"]["codunicocli"].nunique(),
        "cant_A2": detalle[detalle.tipo_alerta == "A2_TELEFONO_NO_ASIGNADO"]["codunicocli"].nunique(),
        "cant_B1": detalle[detalle.tipo_alerta == "B1_SIN_CONTACTO_3_ULTIMOS_MESES"]["codunicocli"].nunique(),
        "cant_B2": detalle[detalle.tipo_alerta == "B2_SIN_CONTACTO_6_ULTIMOS_MESES"]["codunicocli"].nunique(),
        "cant_B3": detalle[detalle.tipo_alerta == "B3_NUNCA_CONTACTO_EFECTIVO"]["codunicocli"].nunique(),
        "cant_nuevos": detalle[detalle.tipo_alerta == "SIN_HISTORICO_CLIENTE_NUEVO"]["codunicocli"].nunique(),
    }

    # --- Auto-chequeo: si el resultado "huele mal", avisamos ANTES de
    # que se confíe en exportar/enviar nada. Esto no reemplaza validar
    # con la query de SSMS, solo evita mandar una alerta con datos que
    # claramente no llegaron bien. ---
    clientes_con_algun_ce = historico_df["codunicocli"].nunique() if len(historico_df) else 0
    pct_nuevos = (resumen["cant_nuevos"] / total_clientes) if total_clientes else 0

    advertencia_datos = None
    if total_clientes > 0 and clientes_con_algun_ce == 0:
        advertencia_datos = (
            "⚠️ NO llegó ningún dato histórico de SQL Server para estos clientes "
            "(0 de {} tienen algún ce registrado). Esto casi seguro es un problema "
            "de conexión/consulta, NO que ningún cliente tenga historial. "
            "No exportes ni envíes este resultado todavía -- corre "
            "diagnostico_meses_faltantes.sql para un cliente que sepas que sí "
            "tiene historial y compáralo."
        ).format(total_clientes)
    elif pct_nuevos > 0.30:
        advertencia_datos = (
            f"⚠️ El {pct_nuevos:.0%} de los clientes salió como 'nuevo sin histórico'. "
            "Si sabes que muchos de ellos SÍ tienen contactos de meses anteriores, "
            "esto es señal de que la consulta no está trayendo bien los datos "
            "(no de que de verdad sean clientes nuevos). Antes de exportar/enviar, "
            "corre diagnostico_meses_faltantes.sql con 2-3 codunicocli que "
            "conozcas y confirma que sí traen sus meses históricos."
        )

    ULTIMO_RESULTADO["df"] = detalle
    ULTIMO_RESULTADO["generado"] = datetime.now().strftime("%d/%m/%Y %H:%M")
    ULTIMO_RESULTADO["resumen"] = resumen

    tabla_html = detalle.sort_values(["tipo_alerta", "codunicocli"]).to_html(
        index=False, classes="tabla-alertas", border=0
    )

    return render_template(
        "index.html",
        resultado=resumen,
        tabla_html=tabla_html,
        generado=ULTIMO_RESULTADO["generado"],
        advertencia_datos=advertencia_datos,
    )


def _armar_excel_alertas():
    """Genera el Excel de detalle en memoria. Devuelve (buffer, nombre)."""
    df = ULTIMO_RESULTADO["df"]
    if df is None or df.empty:
        return None, None

    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        df.sort_values(["tipo_alerta", "codunicocli"]).to_excel(
            writer, index=False, sheet_name="alertas"
        )
    buffer.seek(0)
    nombre = f"alertas_telefonos_bpe_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
    return buffer, nombre


@app.route("/exportar")
def exportar():
    buffer, nombre = _armar_excel_alertas()
    if buffer is None:
        return "No hay resultados para exportar todavía.", 400

    return send_file(
        buffer,
        as_attachment=True,
        download_name=nombre,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
