"""
Web de Alertas de Teléfonos - BPE
----------------------------------
Flujo:
  1. Usuario sube el Excel de asignación del día (columnas: codunicocli,
     telefono1..telefono10, y lo que tenga la asignación).
  2. La app limpia esos teléfonos y arma la lista de codunicocli.
  3. Consulta SQL Server SOLO el histórico de contacto efectivo (ce) de
     esos clientes (enero..mes actual), usando una tabla temporal para
     que el filtro sea rápido aunque subas miles de clientes.
  4. Cruza en pandas: para cada cliente, ¿el teléfono que contactó
     está en telefono1? ¿en otra posición? ¿ni siquiera está asignado?
     ¿hay teléfonos asignados que nunca contactaron?
  5. Muestra un dashboard con los conteos + tabla detalle + botón exportar.

Cómo correr:
    pip install -r requirements.txt
    python app.py
    abrir http://localhost:5000
"""

import io
import os
from datetime import datetime

import pandas as pd
import pyodbc
from flask import Flask, render_template, request, send_file, session

app = Flask(__name__)
app.secret_key = "cambia-esto-por-algo-seguro"

# ---------------------------------------------------------------------------
# CONFIGURACIÓN DE CONEXIÓN - ajusta si tu driver/instancia es distinto
# ---------------------------------------------------------------------------
DB_SERVER = r"s528vp04\bdt"
DB_NAME = "gic"
CAMPANAS = ("cob_bpe_00", "cob_bpe_01", "cob_bpe_02")
MES_DESDE = "202601"  # arranque del histórico

# Guardamos el último resultado en memoria para poder exportarlo.
# Para un solo usuario local esto es suficiente; si la usan varias
# personas a la vez, mejor guardar en disco/DB con un id de sesión.
ULTIMO_RESULTADO = {"df": None, "generado": None, "resumen": None}


def get_conn():
    conn_str = (
        "DRIVER={ODBC Driver 17 for SQL Server};"
        f"SERVER={DB_SERVER};DATABASE={DB_NAME};Trusted_Connection=yes;"
    )
    return pyodbc.connect(conn_str)


def limpiar_numero(valor):
    """Normaliza códigos de cliente y teléfonos que vienen del Excel.
    Pandas suele leer estas columnas como float (ej. 990356503.0), y si
    solo hacemos str(valor) queda "990356503.0" -- ese ".0" hace que la
    comparación contra el histórico de SQL (que sí viene limpio) NUNCA
    calce, y todo termina marcado como "sin contacto" aunque sí lo tuvo.
    Esta función deja solo dígitos, sin decimales ni espacios.
    Devuelve None si no queda ningún dígito válido (o es puro cero).
    """
    if pd.isna(valor):
        return None
    texto = str(valor).strip()
    if texto.endswith(".0"):
        texto = texto[:-2]
    texto = "".join(ch for ch in texto if ch.isdigit())
    if texto == "" or texto == "0":
        return None
    return texto


def leer_asignacion(file_storage):
    """Lee el Excel subido y devuelve un DataFrame limpio:
    codunicocli, posicion (1-10), telefono (solo filas con teléfono válido).
    """
    df = pd.read_excel(file_storage)
    df.columns = [c.strip().lower() for c in df.columns]

    if "codunicocli" not in df.columns:
        raise ValueError("El Excel debe tener una columna 'codunicocli'.")

    cols_tlf = [f"telefono{i}" for i in range(1, 11) if f"telefono{i}" in df.columns]
    if not cols_tlf:
        raise ValueError("No encontré columnas telefono1..telefono10 en el Excel.")

    filas = []
    for _, row in df.iterrows():
        cu = limpiar_numero(row["codunicocli"])
        if cu is None:
            continue
        for i, col in enumerate(cols_tlf, start=1):
            tel = limpiar_numero(row[col])
            if tel is None:
                continue
            filas.append({"codunicocli": cu, "posicion": i, "telefono": tel})

    return pd.DataFrame(filas)


def obtener_historico_ce(codunicoclis):
    """Trae de SQL Server el histórico de contacto efectivo SOLO para
    los clientes de la lista, usando una tabla temporal para el filtro."""
    if not codunicoclis:
        return pd.DataFrame(columns=["codunicocli", "mes", "telefono"])

    codunicoclis = list({c for c in (limpiar_numero(x) for x in codunicoclis) if c is not None})

    conn = get_conn()
    cursor = conn.cursor()
    cursor.fast_executemany = True

    cursor.execute("CREATE TABLE #clientes_hoy (codunicocli VARCHAR(50))")
    cursor.executemany(
        "INSERT INTO #clientes_hoy (codunicocli) VALUES (?)",
        [(c,) for c in codunicoclis],
    )
    conn.commit()

    query = f"""
        with tipis as (
            select
                periodo as mes,
                [contact id] as codunicocli,
                [wrap-up],
                right(dnis,9) as telefono,
                orden = row_number() over (partition by [contact id], periodo order by fecha_key asc)
            from ykr_tb_cob_intentos as a
            inner join (
                select conlusion_cloud as conclusion, 1 as resultado
                from ob_conclusiones_cloud_5
                where tipo_resultado in ('pdp','pdp - fdp','contacto - efectivo')
            ) as b on b.conclusion = a.[wrap-up]
            where b.resultado = 1
              and [campaign name] in {CAMPANAS}
              and [contact id] in (select codunicocli from #clientes_hoy)

            union all

            select
                periodo as mes,
                [contact id] as codunicocli,
                [wrap-up],
                right(dnis,9) as telefono,
                orden = row_number() over (partition by [contact id], periodo order by fecha_key asc)
            from ykr_tb_cob_intentos_bkp as a
            inner join (
                select conlusion_cloud as conclusion, 1 as resultado
                from ob_conclusiones_cloud_5
                where tipo_resultado in ('pdp','pdp - fdp','contacto - efectivo')
            ) as b on b.conclusion = a.[wrap-up]
            where b.resultado = 1
              and [campaign name] in {CAMPANAS}
              and cast(periodo as int) >= {MES_DESDE}
              and [contact id] in (select codunicocli from #clientes_hoy)
        )
        select codunicocli, mes, telefono
        from tipis
        where orden = 1;
    """
    hist = pd.read_sql(query, conn)
    conn.close()

    hist.columns = [c.lower() for c in hist.columns]
    hist["codunicocli"] = hist["codunicocli"].apply(limpiar_numero)
    hist["telefono"] = hist["telefono"].apply(limpiar_numero)
    hist = hist.dropna(subset=["codunicocli", "telefono"])
    return hist


def cruzar_alertas(asignacion_df, historico_df):
    """Devuelve el detalle de alertas por cliente + teléfono.
    Ambos DataFrames ya llegan con codunicocli/telefono limpios
    (puros dígitos, sin .0) desde leer_asignacion() y obtener_historico_ce().
    """
    asignacion_df = asignacion_df.copy()

    # --- A1 y A2: cada telefono con ce, ¿en qué posición está asignado? ---
    ce_unicos = historico_df.drop_duplicates(subset=["codunicocli", "telefono"])
    cruce = ce_unicos.merge(
        asignacion_df[["codunicocli", "posicion", "telefono"]],
        on=["codunicocli", "telefono"],
        how="left",
    )

    def flag_priorizacion(row):
        if pd.isna(row["posicion"]):
            return "A2_TELEFONO_NO_ASIGNADO"
        elif int(row["posicion"]) == 1:
            return "ok"
        else:
            return "A1_SCORE_MAL_PRIORIZADO"

    cruce["tipo_alerta"] = cruce.apply(flag_priorizacion, axis=1)
    alertas_1_2 = cruce[cruce["tipo_alerta"] != "ok"][
        ["codunicocli", "telefono", "posicion", "tipo_alerta"]
    ]

    # --- A3: teléfonos asignados que NUNCA tuvieron ce ---
    tel_con_ce = set(zip(ce_unicos["codunicocli"], ce_unicos["telefono"]))
    asignacion_df["tiene_ce"] = asignacion_df.apply(
        lambda r: (r["codunicocli"], r["telefono"]) in tel_con_ce, axis=1
    )
    alertas_3 = asignacion_df[~asignacion_df["tiene_ce"]][
        ["codunicocli", "telefono", "posicion"]
    ].copy()
    alertas_3["tipo_alerta"] = "A3_TELEFONO_SIN_CONTACTO"

    detalle = pd.concat([alertas_1_2, alertas_3], ignore_index=True)
    return detalle


@app.route("/", methods=["GET"])
def index():
    return render_template("index.html", resultado=None)


@app.route("/procesar", methods=["POST"])
def procesar():
    archivo = request.files.get("archivo_asignacion")
    if not archivo:
        return render_template("index.html", error="Sube un archivo primero.")

    try:
        asignacion_df = leer_asignacion(archivo)
        historico_df = obtener_historico_ce(asignacion_df["codunicocli"].unique().tolist())
        detalle = cruzar_alertas(asignacion_df, historico_df)
    except Exception as e:
        return render_template("index.html", error=f"Error procesando el archivo: {e}")

    total_clientes = asignacion_df["codunicocli"].nunique()
    clientes_con_alerta = detalle["codunicocli"].nunique()

    resumen = {
        "total_clientes": total_clientes,
        "clientes_con_alerta": clientes_con_alerta,
        "cant_A1": detalle[detalle.tipo_alerta == "A1_SCORE_MAL_PRIORIZADO"]["codunicocli"].nunique(),
        "cant_A2": detalle[detalle.tipo_alerta == "A2_TELEFONO_NO_ASIGNADO"]["codunicocli"].nunique(),
        "cant_A3": detalle[detalle.tipo_alerta == "A3_TELEFONO_SIN_CONTACTO"]["codunicocli"].nunique(),
    }

    ULTIMO_RESULTADO["df"] = detalle
    ULTIMO_RESULTADO["generado"] = datetime.now().strftime("%d/%m/%Y %H:%M")
    ULTIMO_RESULTADO["resumen"] = resumen

    tabla_html = detalle.sort_values(["tipo_alerta", "codunicocli"]).to_html(
        index=False, classes="tabla-alertas", border=0
    )

    return render_template(
        "index.html",
        resultado=resumen,
        tabla_html=tabla_html,
        generado=ULTIMO_RESULTADO["generado"],
    )


def _armar_excel_alertas():
    """Genera el Excel de detalle en memoria. Devuelve (buffer, nombre)."""
    df = ULTIMO_RESULTADO["df"]
    if df is None or df.empty:
        return None, None

    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        df.sort_values(["tipo_alerta", "codunicocli"]).to_excel(
            writer, index=False, sheet_name="alertas"
        )
    buffer.seek(0)
    nombre = f"alertas_telefonos_bpe_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
    return buffer, nombre


@app.route("/exportar")
def exportar():
    buffer, nombre = _armar_excel_alertas()
    if buffer is None:
        return "No hay resultados para exportar todavía.", 400

    return send_file(
        buffer,
        as_attachment=True,
        download_name=nombre,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
